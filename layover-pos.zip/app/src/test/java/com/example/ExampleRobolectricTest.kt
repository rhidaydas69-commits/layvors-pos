package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.DatabaseHelper
import com.example.data.PaperSize
import com.example.data.PosSettings
import com.example.data.entities.Order
import com.example.data.entities.OrderItem
import com.example.printer.EscPosPrinter
import com.example.ui.DailySalesSummary
import com.example.ui.OrderFilterDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context verifies Layover POS app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Layover POS", appName)
    }

    @Test
    fun `esc pos printer generates valid customer bill and kot bytes`() {
        val settings = PosSettings(
            restaurantName = "Layover Cafe",
            address = "123 Main St",
            phone = "555-1234",
            paperSize = PaperSize.MM_58
        )
        val order = Order(
            id = 101,
            orderDate = "2026-09-27 12:30",
            orderType = "Dine-In",
            tableNumber = "T-1",
            totalAmount = 20.00,
            discount = 2.00,
            netAmount = 18.00,
            paymentMethod = "Cash"
        )
        val items = listOf(
            OrderItem(id = 1, orderId = 101, itemName = "Cheeseburger", price = 10.00, quantity = 2, total = 20.00)
        )

        // Customer Bill
        val billBytes = EscPosPrinter.buildCustomerBillBytes(order, items, settings)
        assertTrue("Bill byte array should not be empty", billBytes.isNotEmpty())
        val billText = EscPosPrinter.buildCustomerBillText(order, items, settings)
        assertTrue(billText.contains("LAYOVER CAFE"))
        assertTrue(billText.contains("Cheeseburger"))
        assertTrue(billText.contains("TOTAL PAYABLE:"))

        // KOT
        val kotBytes = EscPosPrinter.buildKotBytes(order, items, settings)
        assertTrue("KOT byte array should not be empty", kotBytes.isNotEmpty())
        val kotText = EscPosPrinter.buildKotText(order, items, settings)
        assertTrue(kotText.contains("KITCHEN ORDER TICKET"))
        assertTrue(kotText.contains("2x"))
    }

    @Test
    fun `database helper initializes tables and seed data`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dbHelper = DatabaseHelper(context)
        val categories = dbHelper.getAllCategories()
        assertTrue("Should have seeded categories", categories.isNotEmpty())

        val items = dbHelper.getAllItems()
        assertTrue("Should have seeded food items", items.isNotEmpty())

        val orders = dbHelper.getAllOrders()
        assertTrue("Should have seeded sample orders for daily sales tracking", orders.isNotEmpty())
    }

    @Test
    fun `daily sales summary correctly aggregates order metrics`() {
        val orders = listOf(
            Order(id = 1, orderDate = "2026-09-27 10:00", orderType = "Dine-In", tableNumber = "T1", totalAmount = 30.0, discount = 5.0, netAmount = 25.0, paymentMethod = "Cash"),
            Order(id = 2, orderDate = "2026-09-27 11:30", orderType = "Takeaway", tableNumber = "", totalAmount = 50.0, discount = 0.0, netAmount = 50.0, paymentMethod = "Card"),
            Order(id = 3, orderDate = "2026-09-27 13:00", orderType = "Delivery", tableNumber = "", totalAmount = 20.0, discount = 0.0, netAmount = 20.0, paymentMethod = "UPI")
        )

        val totalRev = orders.sumOf { it.netAmount }
        val count = orders.size
        val aov = totalRev / count
        val cash = orders.filter { it.paymentMethod == "Cash" }.sumOf { it.netAmount }
        val card = orders.filter { it.paymentMethod == "Card" }.sumOf { it.netAmount }
        val upi = orders.filter { it.paymentMethod == "UPI" }.sumOf { it.netAmount }

        val summary = DailySalesSummary(
            filterDate = OrderFilterDate.TODAY,
            totalRevenue = totalRev,
            orderCount = count,
            averageTicket = aov,
            cashSales = cash,
            cardSales = card,
            upiSales = upi,
            dineInCount = 1,
            takeawayCount = 1,
            deliveryCount = 1,
            totalDiscounts = 5.0
        )

        assertEquals(95.0, summary.totalRevenue, 0.01)
        assertEquals(3, summary.orderCount)
        assertEquals(31.66, summary.averageTicket, 0.01)
        assertEquals(25.0, summary.cashSales, 0.01)
        assertEquals(50.0, summary.cardSales, 0.01)
        assertEquals(20.0, summary.upiSales, 0.01)
        assertEquals(1, summary.dineInCount)
        assertEquals(1, summary.takeawayCount)
        assertEquals(1, summary.deliveryCount)
        assertEquals(5.0, summary.totalDiscounts, 0.01)
    }
}
