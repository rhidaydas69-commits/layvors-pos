package com.example.printer

import com.example.data.PaperSize
import com.example.data.PosSettings
import com.example.data.entities.Order
import com.example.data.entities.OrderItem
import java.io.ByteArrayOutputStream
import java.nio.charset.Charset
import java.util.Locale

/**
 * ESC/POS command generator supporting 58mm (32 chars) and 80mm (48 chars) thermal printers.
 * Generates both formatted byte arrays for Bluetooth/USB transmission and
 * formatted text for on-screen thermal paper preview.
 */
object EscPosPrinter {

    private val CHARSET: Charset = Charset.forName("CP437")

    // Standard ESC/POS Commands
    val CMD_INIT: ByteArray = byteArrayOf(0x1B, 0x40) // ESC @
    val CMD_ALIGN_LEFT: ByteArray = byteArrayOf(0x1B, 0x61, 0x00) // ESC a 0
    val CMD_ALIGN_CENTER: ByteArray = byteArrayOf(0x1B, 0x61, 0x01) // ESC a 1
    val CMD_ALIGN_RIGHT: ByteArray = byteArrayOf(0x1B, 0x61, 0x02) // ESC a 2
    val CMD_BOLD_ON: ByteArray = byteArrayOf(0x1B, 0x45, 0x01) // ESC E 1
    val CMD_BOLD_OFF: ByteArray = byteArrayOf(0x1B, 0x45, 0x00) // ESC E 0
    val CMD_DOUBLE_SIZE_ON: ByteArray = byteArrayOf(0x1D, 0x21, 0x11) // GS ! 0x11 (2x width + 2x height)
    val CMD_DOUBLE_HEIGHT_ON: ByteArray = byteArrayOf(0x1D, 0x21, 0x01) // GS ! 0x01
    val CMD_DOUBLE_WIDTH_ON: ByteArray = byteArrayOf(0x1D, 0x21, 0x10) // GS ! 0x10
    val CMD_NORMAL_SIZE: ByteArray = byteArrayOf(0x1D, 0x21, 0x00) // GS ! 0x00
    val CMD_FEED_3_LINES: ByteArray = byteArrayOf(0x1B, 0x64, 0x03) // ESC d 3
    val CMD_FEED_5_LINES: ByteArray = byteArrayOf(0x1B, 0x64, 0x05) // ESC d 5
    val CMD_PAPER_CUT: ByteArray = byteArrayOf(0x1D, 0x56, 0x41, 0x00) // GS V 65 0 (Full Cut)
    val CMD_LINE_FEED: ByteArray = byteArrayOf(0x0A) // LF

    /**
     * Generates ESC/POS byte array for Customer Receipt / Tax Invoice.
     */
    fun buildCustomerBillBytes(
        order: Order,
        items: List<OrderItem>,
        settings: PosSettings
    ): ByteArray {
        val width = settings.paperSize.charWidth
        val stream = ByteArrayOutputStream()

        fun write(bytes: ByteArray) = stream.write(bytes)
        fun writeText(text: String) {
            stream.write(text.toByteArray(CHARSET))
            stream.write(CMD_LINE_FEED)
        }

        // 1. Initialize
        write(CMD_INIT)

        // 2. Header
        write(CMD_ALIGN_CENTER)
        write(CMD_DOUBLE_SIZE_ON)
        write(CMD_BOLD_ON)
        writeText(settings.restaurantName.uppercase(Locale.getDefault()))
        write(CMD_NORMAL_SIZE)
        write(CMD_BOLD_OFF)

        if (settings.address.isNotBlank()) {
            writeText(settings.address)
        }
        if (settings.phone.isNotBlank()) {
            writeText("Tel: ${settings.phone}")
        }
        write(CMD_BOLD_ON)
        writeText("TAX INVOICE / RECEIPT")
        write(CMD_BOLD_OFF)
        writeText(divider('=', width))

        // 3. Order Info
        write(CMD_ALIGN_LEFT)
        writeText(formatTwoColumn("Order ID: #${order.id}", "Date: ${order.orderDate}", width))
        val tableInfo = if (order.tableNumber.isNotBlank()) "Table: ${order.tableNumber}" else "Type: ${order.orderType}"
        writeText(formatTwoColumn("Type: ${order.orderType}", if (order.tableNumber.isNotBlank()) "Table: ${order.tableNumber}" else "", width))
        writeText(divider('-', width))

        // 4. Items Table Header
        write(CMD_BOLD_ON)
        writeText(formatItemRowHeader(width))
        write(CMD_BOLD_OFF)
        writeText(divider('-', width))

        // 5. Items Rows
        for (item in items) {
            val lines = formatItemRow(item, settings.currencySymbol, width)
            for (line in lines) {
                writeText(line)
            }
        }
        writeText(divider('-', width))

        // 6. Summary Totals
        write(CMD_ALIGN_RIGHT)
        writeText(formatTwoColumn("Subtotal:", "${settings.currencySymbol}${String.format(Locale.US, "%.2f", order.totalAmount)}", width))
        if (order.discount > 0) {
            writeText(formatTwoColumn("Discount:", "-${settings.currencySymbol}${String.format(Locale.US, "%.2f", order.discount)}", width))
        }
        val taxAmount = (order.netAmount * (settings.taxRate / 100.0))
        if (settings.taxRate > 0) {
            writeText(formatTwoColumn("Tax (${settings.taxRate}%):", "${settings.currencySymbol}${String.format(Locale.US, "%.2f", taxAmount)}", width))
        }

        write(CMD_BOLD_ON)
        write(CMD_DOUBLE_HEIGHT_ON)
        val finalPayable = order.netAmount + if (settings.taxRate > 0) taxAmount else 0.0
        writeText(formatTwoColumn("TOTAL PAYABLE:", "${settings.currencySymbol}${String.format(Locale.US, "%.2f", finalPayable)}", width))
        write(CMD_NORMAL_SIZE)
        write(CMD_BOLD_OFF)

        write(CMD_ALIGN_LEFT)
        writeText(formatTwoColumn("Payment Mode:", order.paymentMethod.uppercase(Locale.getDefault()), width))
        writeText(divider('=', width))

        // 7. Footer
        write(CMD_ALIGN_CENTER)
        write(CMD_BOLD_ON)
        writeText(settings.footerMessage)
        write(CMD_BOLD_OFF)
        writeText("Offline POS System • Layover POS")
        write(CMD_FEED_3_LINES)
        write(CMD_PAPER_CUT)

        return stream.toByteArray()
    }

    /**
     * Generates ESC/POS byte array for Kitchen Order Ticket (KOT).
     */
    fun buildKotBytes(
        order: Order,
        items: List<OrderItem>,
        settings: PosSettings
    ): ByteArray {
        val width = settings.paperSize.charWidth
        val stream = ByteArrayOutputStream()

        fun write(bytes: ByteArray) = stream.write(bytes)
        fun writeText(text: String) {
            stream.write(text.toByteArray(CHARSET))
            stream.write(CMD_LINE_FEED)
        }

        // 1. Initialize
        write(CMD_INIT)
        write(CMD_ALIGN_CENTER)
        write(CMD_DOUBLE_SIZE_ON)
        write(CMD_BOLD_ON)
        writeText("*** KITCHEN ORDER TICKET ***")
        writeText("KOT #${order.id}")
        write(CMD_NORMAL_SIZE)
        write(CMD_BOLD_OFF)

        write(CMD_ALIGN_LEFT)
        writeText(divider('=', width))
        write(CMD_BOLD_ON)
        val tableStr = if (order.tableNumber.isNotBlank()) "TABLE: ${order.tableNumber}" else "TAKEAWAY"
        writeText(formatTwoColumn("TYPE: ${order.orderType.uppercase(Locale.getDefault())}", tableStr, width))
        writeText("TIME: ${order.orderDate}")
        write(CMD_BOLD_OFF)
        writeText(divider('-', width))

        // Items for Kitchen
        write(CMD_BOLD_ON)
        writeText(formatKotHeader(width))
        write(CMD_BOLD_OFF)
        writeText(divider('-', width))

        for (item in items) {
            write(CMD_BOLD_ON)
            write(CMD_DOUBLE_HEIGHT_ON)
            val qtyStr = "[ ${item.quantity}x ]"
            val itemStr = item.itemName
            writeText("$qtyStr $itemStr")
            write(CMD_NORMAL_SIZE)
            write(CMD_BOLD_OFF)
            writeText(divider('.', width))
        }

        write(CMD_ALIGN_CENTER)
        writeText(divider('=', width))
        writeText("*** PLEASE PREPARE IMMEDIATELY ***")
        write(CMD_FEED_5_LINES)
        write(CMD_PAPER_CUT)

        return stream.toByteArray()
    }

    /**
     * Formats customer bill as plain text with monospaced columns for on-screen receipt preview.
     */
    fun buildCustomerBillText(
        order: Order,
        items: List<OrderItem>,
        settings: PosSettings
    ): String {
        val width = settings.paperSize.charWidth
        val sb = StringBuilder()

        sb.appendLine(centerText(settings.restaurantName.uppercase(Locale.getDefault()), width))
        if (settings.address.isNotBlank()) sb.appendLine(centerText(settings.address, width))
        if (settings.phone.isNotBlank()) sb.appendLine(centerText("Tel: ${settings.phone}", width))
        sb.appendLine(centerText("TAX INVOICE / RECEIPT", width))
        sb.appendLine(divider('=', width))

        sb.appendLine(formatTwoColumn("Order ID: #${order.id}", "Date: ${order.orderDate}", width))
        val tablePart = if (order.tableNumber.isNotBlank()) "Table: ${order.tableNumber}" else ""
        sb.appendLine(formatTwoColumn("Type: ${order.orderType}", tablePart, width))
        sb.appendLine(divider('-', width))

        sb.appendLine(formatItemRowHeader(width))
        sb.appendLine(divider('-', width))

        for (item in items) {
            val lines = formatItemRow(item, settings.currencySymbol, width)
            for (line in lines) {
                sb.appendLine(line)
            }
        }
        sb.appendLine(divider('-', width))

        sb.appendLine(formatTwoColumn("Subtotal:", "${settings.currencySymbol}${String.format(Locale.US, "%.2f", order.totalAmount)}", width))
        if (order.discount > 0) {
            sb.appendLine(formatTwoColumn("Discount:", "-${settings.currencySymbol}${String.format(Locale.US, "%.2f", order.discount)}", width))
        }
        val taxAmount = (order.netAmount * (settings.taxRate / 100.0))
        if (settings.taxRate > 0) {
            sb.appendLine(formatTwoColumn("Tax (${settings.taxRate}%):", "${settings.currencySymbol}${String.format(Locale.US, "%.2f", taxAmount)}", width))
        }

        val finalPayable = order.netAmount + if (settings.taxRate > 0) taxAmount else 0.0
        sb.appendLine(formatTwoColumn("TOTAL PAYABLE:", "${settings.currencySymbol}${String.format(Locale.US, "%.2f", finalPayable)}", width))
        sb.appendLine(formatTwoColumn("Payment Method:", order.paymentMethod.uppercase(Locale.getDefault()), width))
        sb.appendLine(divider('=', width))

        sb.appendLine(centerText(settings.footerMessage, width))
        sb.appendLine(centerText("Offline POS System • Layover POS", width))

        return sb.toString()
    }

    /**
     * Formats KOT ticket as plain text for on-screen receipt preview.
     */
    fun buildKotText(
        order: Order,
        items: List<OrderItem>,
        settings: PosSettings
    ): String {
        val width = settings.paperSize.charWidth
        val sb = StringBuilder()

        sb.appendLine(centerText("*** KITCHEN ORDER TICKET ***", width))
        sb.appendLine(centerText("KOT #${order.id}", width))
        sb.appendLine(divider('=', width))

        val tableStr = if (order.tableNumber.isNotBlank()) "TABLE: ${order.tableNumber}" else "TAKEAWAY"
        sb.appendLine(formatTwoColumn("TYPE: ${order.orderType.uppercase(Locale.getDefault())}", tableStr, width))
        sb.appendLine("TIME: ${order.orderDate}")
        sb.appendLine(divider('-', width))

        sb.appendLine(formatKotHeader(width))
        sb.appendLine(divider('-', width))

        for (item in items) {
            sb.appendLine(String.format(Locale.US, "%-4s %s", "${item.quantity}x", item.itemName))
            sb.appendLine(divider('.', width))
        }

        sb.appendLine(divider('=', width))
        sb.appendLine(centerText("*** PLEASE PREPARE IMMEDIATELY ***", width))

        return sb.toString()
    }

    // String formatting helpers
    private fun centerText(text: String, width: Int): String {
        if (text.length >= width) return text.take(width)
        val leftPad = (width - text.length) / 2
        return " ".repeat(leftPad) + text
    }

    private fun divider(char: Char, width: Int): String {
        return char.toString().repeat(width)
    }

    private fun formatTwoColumn(left: String, right: String, width: Int): String {
        val available = width - right.length
        if (available <= 0) return "$left $right".take(width)
        return left.padEnd(available).take(available) + right
    }

    private fun formatItemRowHeader(width: Int): String {
        return if (width <= 32) {
            // 58mm: QTY(3) ITEM(15) TOT(7)
            String.format(Locale.US, "%-3s %-18s %8s", "QTY", "ITEM", "TOTAL")
        } else {
            // 80mm: QTY(4) ITEM(24) PRICE(8) TOTAL(8)
            String.format(Locale.US, "%-4s %-24s %8s %8s", "QTY", "ITEM", "PRICE", "TOTAL")
        }
    }

    private fun formatKotHeader(width: Int): String {
        return String.format(Locale.US, "%-4s %s", "QTY", "ITEM DESCRIPTION")
    }

    private fun formatItemRow(item: OrderItem, currency: String, width: Int): List<String> {
        val lines = mutableListOf<String>()
        val priceStr = "$currency${String.format(Locale.US, "%.2f", item.price)}"
        val totalStr = "$currency${String.format(Locale.US, "%.2f", item.total)}"
        val qtyStr = "${item.quantity}"

        if (width <= 32) {
            // 58mm
            val itemMaxLen = 18
            val name = item.itemName
            if (name.length <= itemMaxLen) {
                lines.add(String.format(Locale.US, "%-3s %-18s %8s", qtyStr, name, totalStr))
            } else {
                val firstLine = name.take(itemMaxLen)
                val remaining = name.drop(itemMaxLen)
                lines.add(String.format(Locale.US, "%-3s %-18s %8s", qtyStr, firstLine, totalStr))
                lines.add("    ${remaining.take(itemMaxLen)}")
            }
        } else {
            // 80mm
            val itemMaxLen = 24
            val name = item.itemName
            if (name.length <= itemMaxLen) {
                lines.add(String.format(Locale.US, "%-4s %-24s %8s %8s", qtyStr, name, priceStr, totalStr))
            } else {
                val firstLine = name.take(itemMaxLen)
                val remaining = name.drop(itemMaxLen)
                lines.add(String.format(Locale.US, "%-4s %-24s %8s %8s", qtyStr, firstLine, priceStr, totalStr))
                lines.add("     ${remaining.take(itemMaxLen)}")
            }
        }
        return lines
    }
}
