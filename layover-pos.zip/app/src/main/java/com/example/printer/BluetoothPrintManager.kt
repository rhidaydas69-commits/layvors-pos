package com.example.printer

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.util.UUID

data class PairedPrinterDevice(
    val name: String,
    val address: String
)

sealed class PrintResult {
    data class Success(val message: String) : PrintResult()
    data class Failure(val error: String) : PrintResult()
}

/**
 * Native Bluetooth ESC/POS Thermal Print Manager.
 * Communicates with 58mm and 80mm Bluetooth thermal printers (Sunmi, Xprinter, Epson, POS-58, etc.)
 * over the standard Serial Port Profile (SPP) RFCOMM channel.
 */
class BluetoothPrintManager(private val context: Context) {

    companion object {
        // Standard Serial Port Profile (SPP) UUID used by ESC/POS Bluetooth printers
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        manager?.adapter ?: BluetoothAdapter.getDefaultAdapter()
    }

    /**
     * Checks if Bluetooth hardware is available on this POS device.
     */
    fun isBluetoothAvailable(): Boolean = bluetoothAdapter != null

    /**
     * Checks if Bluetooth is turned on.
     */
    fun isBluetoothEnabled(): Boolean = bluetoothAdapter?.isEnabled == true

    /**
     * Retrieves list of already paired/bonded Bluetooth printers.
     */
    @SuppressLint("MissingPermission")
    fun getPairedPrinters(): List<PairedPrinterDevice> {
        val adapter = bluetoothAdapter ?: return emptyList()
        return try {
            val devices = adapter.bondedDevices ?: return emptyList()
            devices.map { device ->
                PairedPrinterDevice(
                    name = device.name ?: "Unknown Device",
                    address = device.address
                )
            }
        } catch (_: SecurityException) {
            emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * Sends ESC/POS byte array to the selected Bluetooth printer.
     */
    @SuppressLint("MissingPermission")
    suspend fun printBytes(
        bytes: ByteArray,
        targetAddress: String?
    ): PrintResult = withContext(Dispatchers.IO) {
        val adapter = bluetoothAdapter
            ?: return@withContext PrintResult.Failure("Bluetooth is not supported on this device.")

        if (!adapter.isEnabled) {
            return@withContext PrintResult.Failure("Bluetooth is disabled. Please enable Bluetooth in Android settings.")
        }

        val address = targetAddress?.takeIf { it.isNotBlank() }
            ?: return@withContext PrintResult.Failure("No Bluetooth printer selected. Please choose a printer in Settings.")

        var socket: BluetoothSocket? = null
        var outputStream: OutputStream? = null

        try {
            val device: BluetoothDevice = adapter.getRemoteDevice(address)
            // Cancel discovery before connecting as it slows down connection
            try {
                adapter.cancelDiscovery()
            } catch (_: Exception) {}

            // Create RFCOMM socket using standard SPP UUID
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            socket.connect()

            outputStream = socket.outputStream
            outputStream.write(bytes)
            outputStream.flush()

            PrintResult.Success("Printed successfully to ${device.name ?: address}")
        } catch (se: SecurityException) {
            PrintResult.Failure("Bluetooth permission denied. Grant BLUETOOTH_CONNECT permission in Settings.")
        } catch (e: Exception) {
            PrintResult.Failure("Failed to print: ${e.localizedMessage ?: "Printer connection error"}")
        } finally {
            try {
                outputStream?.close()
            } catch (_: Exception) {}
            try {
                socket?.close()
            } catch (_: Exception) {}
        }
    }
}
