package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.PosDatabase
import com.example.data.PosRepository
import com.example.data.PosSettings
import com.example.data.SettingsRepository
import com.example.data.entities.Category
import com.example.data.entities.Item
import com.example.data.entities.ItemVariant
import com.example.data.entities.Order
import com.example.data.entities.OrderItem
import com.example.data.entities.toVariantsString
import com.example.printer.BluetoothPrintManager
import com.example.printer.EscPosPrinter
import com.example.printer.PairedPrinterDevice
import com.example.printer.PrintResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CartItem(
    val item: Item,
    val selectedVariant: ItemVariant? = null,
    val quantity: Int
) {
    val unitPrice: Double get() = selectedVariant?.price ?: item.price
    val total: Double get() = unitPrice * quantity
    val displayName: String get() = if (selectedVariant != null) "${item.name} (${selectedVariant.name})" else item.name
    val cartKey: String get() = "${item.id}_${selectedVariant?.name ?: "base"}"
}

enum class OrderFilterDate(val label: String) {
    TODAY("Today"),
    YESTERDAY("Yesterday"),
    ALL_TIME("All Orders")
}

data class DailySalesSummary(
    val filterDate: OrderFilterDate = OrderFilterDate.TODAY,
    val totalRevenue: Double = 0.0,
    val orderCount: Int = 0,
    val averageTicket: Double = 0.0,
    val cashSales: Double = 0.0,
    val cardSales: Double = 0.0,
    val upiSales: Double = 0.0,
    val dineInCount: Int = 0,
    val takeawayCount: Int = 0,
    val deliveryCount: Int = 0,
    val totalDiscounts: Double = 0.0
)

sealed interface ActiveDialog {
    data object Payment : ActiveDialog
    data object Settings : ActiveDialog
    data class ReceiptPreview(
        val title: String,
        val receiptText: String,
        val rawBytes: ByteArray,
        val isKot: Boolean
    ) : ActiveDialog
    data object OrderHistory : ActiveDialog
    data class AddOrEditItem(val itemToEdit: Item? = null, val defaultCategoryId: Long? = null) : ActiveDialog
    data object ManageCategories : ActiveDialog
    data class SelectVariant(val item: Item) : ActiveDialog
}

class PosViewModel(application: Application) : AndroidViewModel(application) {

    private val database = PosDatabase.getDatabase(application, viewModelScope)
    private val repository = PosRepository(database.posDao())
    private val settingsRepository = SettingsRepository(application)
    val bluetoothPrintManager = BluetoothPrintManager(application)

    // Data streams from SQLite/Room
    val categories: StateFlow<List<Category>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allItems: StateFlow<List<Item>> = repository.allItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categoryItemCounts: StateFlow<Map<Long, Int>> = allItems.combine(allItems) { items, _ ->
        items.groupBy { it.categoryId }.mapValues { it.value.size }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val orders: StateFlow<List<Order>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Settings state
    private val _settings = MutableStateFlow(settingsRepository.getSettings())
    val settings: StateFlow<PosSettings> = _settings.asStateFlow()

    // Filter & Search states
    private val _selectedCategory = MutableStateFlow<Category?>(null)
    val selectedCategory: StateFlow<Category?> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Filtered Items
    val filteredItems: StateFlow<List<Item>> = combine(allItems, _selectedCategory, _searchQuery) { items, cat, query ->
        items.filter { item ->
            val matchesCategory = cat == null || item.categoryId == cat.id
            val matchesQuery = query.isBlank() || item.name.contains(query, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Cart State
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    private val _orderType = MutableStateFlow("Dine-In")
    val orderType: StateFlow<String> = _orderType.asStateFlow()

    private val _tableNumber = MutableStateFlow("Table 1")
    val tableNumber: StateFlow<String> = _tableNumber.asStateFlow()

    private val _discountPercent = MutableStateFlow(0.0)
    val discountPercent: StateFlow<Double> = _discountPercent.asStateFlow()

    private val _customDiscountAmount = MutableStateFlow(0.0)
    val customDiscountAmount: StateFlow<Double> = _customDiscountAmount.asStateFlow()

    // Calculation states
    val subtotal: StateFlow<Double> = _cartItems.combine(_cartItems) { items, _ ->
        items.sumOf { it.total }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val discountAmount: StateFlow<Double> = combine(subtotal, _discountPercent, _customDiscountAmount) { sub, pct, custom ->
        if (custom > 0.0) {
            custom.coerceAtMost(sub)
        } else {
            (sub * (pct / 100.0)).coerceAtMost(sub)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val netAmount: StateFlow<Double> = combine(subtotal, discountAmount) { sub, disc ->
        (sub - disc).coerceAtLeast(0.0)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val taxAmount: StateFlow<Double> = combine(netAmount, _settings) { net, st ->
        if (st.taxRate > 0) net * (st.taxRate / 100.0) else 0.0
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val grandTotal: StateFlow<Double> = combine(netAmount, taxAmount) { net, tax ->
        net + tax
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // UI Dialog & Notification State
    private val _activeDialog = MutableStateFlow<ActiveDialog?>(null)
    val activeDialog: StateFlow<ActiveDialog?> = _activeDialog.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    // Paired Bluetooth Devices
    private val _pairedPrinters = MutableStateFlow<List<PairedPrinterDevice>>(emptyList())
    val pairedPrinters: StateFlow<List<PairedPrinterDevice>> = _pairedPrinters.asStateFlow()

    // Main Navigation Tab (0 = Register/Menu, 1 = Recent Orders & Sales)
    private val _currentMainTab = MutableStateFlow(0)
    val currentMainTab: StateFlow<Int> = _currentMainTab.asStateFlow()

    // Recent Orders & Daily Sales Filter State
    private val _orderFilterDate = MutableStateFlow(OrderFilterDate.TODAY)
    val orderFilterDate: StateFlow<OrderFilterDate> = _orderFilterDate.asStateFlow()

    private val _orderSearchQuery = MutableStateFlow("")
    val orderSearchQuery: StateFlow<String> = _orderSearchQuery.asStateFlow()

    private val _orderPaymentFilter = MutableStateFlow("ALL")
    val orderPaymentFilter: StateFlow<String> = _orderPaymentFilter.asStateFlow()

    // Cache of order items mapped by orderId
    private val _orderItemsCache = MutableStateFlow<Map<Long, List<OrderItem>>>(emptyMap())
    val orderItemsCache: StateFlow<Map<Long, List<OrderItem>>> = _orderItemsCache.asStateFlow()

    // Expanded order IDs in Recent Orders list
    private val _expandedOrderIds = MutableStateFlow<Set<Long>>(emptySet())
    val expandedOrderIds: StateFlow<Set<Long>> = _expandedOrderIds.asStateFlow()

    // Filtered Recent Orders from SQLite
    val filteredRecentOrders: StateFlow<List<Order>> = combine(
        orders,
        _orderFilterDate,
        _orderSearchQuery,
        _orderPaymentFilter
    ) { ordersList, dateFilter, query, payFilter ->
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val yesterdayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            .format(Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000L))

        ordersList.filter { order ->
            val matchesDate = when (dateFilter) {
                OrderFilterDate.TODAY -> order.orderDate.startsWith(todayStr)
                OrderFilterDate.YESTERDAY -> order.orderDate.startsWith(yesterdayStr)
                OrderFilterDate.ALL_TIME -> true
            }
            val matchesPayment = payFilter == "ALL" || order.paymentMethod.equals(payFilter, ignoreCase = true)
            val matchesQuery = query.isBlank() ||
                    order.id.toString().contains(query) ||
                    order.tableNumber.contains(query, ignoreCase = true) ||
                    order.orderType.contains(query, ignoreCase = true)
            matchesDate && matchesPayment && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Aggregated Daily Sales Summary for tracking revenue
    val dailySalesSummary: StateFlow<DailySalesSummary> = combine(
        orders,
        _orderFilterDate
    ) { ordersList, dateFilter ->
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val yesterdayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            .format(Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000L))

        val scopedOrders = ordersList.filter { order ->
            when (dateFilter) {
                OrderFilterDate.TODAY -> order.orderDate.startsWith(todayStr)
                OrderFilterDate.YESTERDAY -> order.orderDate.startsWith(yesterdayStr)
                OrderFilterDate.ALL_TIME -> true
            }
        }

        val totalRev = scopedOrders.sumOf { it.netAmount }
        val count = scopedOrders.size
        val aov = if (count > 0) totalRev / count else 0.0
        val cash = scopedOrders.filter { it.paymentMethod.equals("Cash", ignoreCase = true) }.sumOf { it.netAmount }
        val card = scopedOrders.filter { it.paymentMethod.equals("Card", ignoreCase = true) }.sumOf { it.netAmount }
        val upi = scopedOrders.filter { it.paymentMethod.contains("UPI", ignoreCase = true) }.sumOf { it.netAmount }
        val dineIn = scopedOrders.count { it.orderType.equals("Dine-In", ignoreCase = true) }
        val takeaway = scopedOrders.count { it.orderType.equals("Takeaway", ignoreCase = true) }
        val delivery = scopedOrders.count { it.orderType.equals("Delivery", ignoreCase = true) }
        val discounts = scopedOrders.sumOf { it.discount }

        DailySalesSummary(
            filterDate = dateFilter,
            totalRevenue = totalRev,
            orderCount = count,
            averageTicket = aov,
            cashSales = cash,
            cardSales = card,
            upiSales = upi,
            dineInCount = dineIn,
            takeawayCount = takeaway,
            deliveryCount = delivery,
            totalDiscounts = discounts
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DailySalesSummary())

    // Live badge of today's total revenue
    val todayRevenue: StateFlow<Double> = orders.combine(orders) { ordersList, _ ->
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        ordersList.filter { it.orderDate.startsWith(todayStr) }.sumOf { it.netAmount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    init {
        refreshPairedPrinters()
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val dao = database.posDao()
            if (dao.getCategoryCount() == 0 || dao.getItemCount() == 0) {
                PosDatabase.populateInitialData(dao)
            }
        }
    }

    fun refreshPairedPrinters() {
        _pairedPrinters.value = bluetoothPrintManager.getPairedPrinters()
    }

    // Cart Actions (with Variant support)
    fun addToCart(item: Item, variant: ItemVariant? = null) {
        if (variant == null && item.hasVariants) {
            _activeDialog.value = ActiveDialog.SelectVariant(item)
            return
        }

        val current = _cartItems.value.toMutableList()
        val targetKey = "${item.id}_${variant?.name ?: "base"}"
        val index = current.indexOfFirst { it.cartKey == targetKey }
        if (index != -1) {
            val existing = current[index]
            current[index] = existing.copy(quantity = existing.quantity + 1)
        } else {
            current.add(CartItem(item = item, selectedVariant = variant, quantity = 1))
        }
        _cartItems.value = current
    }

    fun incrementCartItem(cartKey: String) {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.cartKey == cartKey }
        if (index != -1) {
            current[index] = current[index].copy(quantity = current[index].quantity + 1)
            _cartItems.value = current
        }
    }

    fun decrementCartItem(cartKey: String) {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.cartKey == cartKey }
        if (index != -1) {
            val existing = current[index]
            if (existing.quantity > 1) {
                current[index] = existing.copy(quantity = existing.quantity - 1)
            } else {
                current.removeAt(index)
            }
            _cartItems.value = current
        }
    }

    fun removeCartItem(cartKey: String) {
        _cartItems.value = _cartItems.value.filter { it.cartKey != cartKey }
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _discountPercent.value = 0.0
        _customDiscountAmount.value = 0.0
    }

    // Filter Actions
    fun selectCategory(category: Category?) {
        if (category == null || _selectedCategory.value?.id == category.id) {
            _selectedCategory.value = null
        } else {
            _selectedCategory.value = category
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setOrderType(type: String) {
        _orderType.value = type
    }

    fun setTableNumber(table: String) {
        _tableNumber.value = table
    }

    fun setDiscountPercent(percent: Double) {
        _discountPercent.value = percent
        _customDiscountAmount.value = 0.0
    }

    fun setCustomDiscountAmount(amount: Double) {
        _customDiscountAmount.value = amount
        _discountPercent.value = 0.0
    }

    fun openDialog(dialog: ActiveDialog) {
        if (dialog is ActiveDialog.Settings) {
            refreshPairedPrinters()
        }
        _activeDialog.value = dialog
    }

    fun closeDialog() {
        _activeDialog.value = null
    }

    fun dismissBanner() {
        _statusBanner.value = null
    }

    // KOT Printing (Kitchen Order Ticket)
    fun printKot() {
        val items = _cartItems.value
        if (items.isEmpty()) {
            _statusBanner.value = "Cart is empty. Add items to print KOT."
            return
        }

        val tempOrder = Order(
            id = System.currentTimeMillis() % 10000,
            orderDate = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date()),
            orderType = _orderType.value,
            tableNumber = if (_orderType.value == "Dine-In") _tableNumber.value else "",
            totalAmount = subtotal.value,
            discount = discountAmount.value,
            netAmount = netAmount.value,
            paymentMethod = "PENDING"
        )

        val orderItems = items.map {
            OrderItem(
                orderId = tempOrder.id,
                itemName = it.displayName,
                price = it.unitPrice,
                quantity = it.quantity,
                total = it.total
            )
        }

        val kotBytes = EscPosPrinter.buildKotBytes(tempOrder, orderItems, _settings.value)
        val kotText = EscPosPrinter.buildKotText(tempOrder, orderItems, _settings.value)

        // Attempt Bluetooth dispatch in background
        viewModelScope.launch {
            val btAddress = _settings.value.bluetoothDeviceAddress
            if (btAddress.isNotBlank()) {
                val res = bluetoothPrintManager.printBytes(kotBytes, btAddress)
                when (res) {
                    is PrintResult.Success -> _statusBanner.value = "KOT sent to printer!"
                    is PrintResult.Failure -> _statusBanner.value = "Bluetooth notice: ${res.error}"
                }
            }
        }

        // Always show on-screen high-fidelity thermal preview dialog
        _activeDialog.value = ActiveDialog.ReceiptPreview(
            title = "Kitchen Order Ticket (KOT)",
            receiptText = kotText,
            rawBytes = kotBytes,
            isKot = true
        )
    }

    // Complete Payment & Save Order to SQLite
    fun completePayment(paymentMethod: String, cashTendered: Double? = null) {
        val items = _cartItems.value
        if (items.isEmpty()) return

        val orderDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        val order = Order(
            orderDate = orderDate,
            orderType = _orderType.value,
            tableNumber = if (_orderType.value == "Dine-In") _tableNumber.value else "",
            totalAmount = subtotal.value,
            discount = discountAmount.value,
            netAmount = grandTotal.value,
            paymentMethod = paymentMethod
        )

        val orderItems = items.map {
            OrderItem(
                itemName = it.displayName,
                price = it.unitPrice,
                quantity = it.quantity,
                total = it.total,
                orderId = 0
            )
        }

        viewModelScope.launch {
            val orderId = repository.createOrder(order, orderItems)
            val savedOrder = order.copy(id = orderId)
            val savedItems = orderItems.map { it.copy(orderId = orderId) }

            val billBytes = EscPosPrinter.buildCustomerBillBytes(savedOrder, savedItems, _settings.value)
            val billText = EscPosPrinter.buildCustomerBillText(savedOrder, savedItems, _settings.value)

            // Dispatch Bluetooth print if configured
            val btAddress = _settings.value.bluetoothDeviceAddress
            if (btAddress.isNotBlank()) {
                val printRes = bluetoothPrintManager.printBytes(billBytes, btAddress)
                when (printRes) {
                    is PrintResult.Success -> _statusBanner.value = "Receipt printed via Bluetooth!"
                    is PrintResult.Failure -> _statusBanner.value = "Print: ${printRes.error}"
                }
            }

            clearCart()
            _activeDialog.value = ActiveDialog.ReceiptPreview(
                title = "Customer Bill Receipt #${orderId}",
                receiptText = billText,
                rawBytes = billBytes,
                isKot = false
            )
        }
    }

    // Reprint from Order History
    fun reprintOrder(order: Order, isKot: Boolean = false) {
        viewModelScope.launch {
            val items = repository.getOrderItemsForOrder(order.id)
            if (isKot) {
                val bytes = EscPosPrinter.buildKotBytes(order, items, _settings.value)
                val text = EscPosPrinter.buildKotText(order, items, _settings.value)
                sendToBluetoothIfConfigured(bytes)
                _activeDialog.value = ActiveDialog.ReceiptPreview(
                    title = "Reprint KOT #${order.id}",
                    receiptText = text,
                    rawBytes = bytes,
                    isKot = true
                )
            } else {
                val bytes = EscPosPrinter.buildCustomerBillBytes(order, items, _settings.value)
                val text = EscPosPrinter.buildCustomerBillText(order, items, _settings.value)
                sendToBluetoothIfConfigured(bytes)
                _activeDialog.value = ActiveDialog.ReceiptPreview(
                    title = "Reprint Receipt #${order.id}",
                    receiptText = text,
                    rawBytes = bytes,
                    isKot = false
                )
            }
        }
    }

    fun printRawBytes(bytes: ByteArray) {
        val address = _settings.value.bluetoothDeviceAddress
        if (address.isNotBlank()) {
            viewModelScope.launch {
                val res = bluetoothPrintManager.printBytes(bytes, address)
                when (res) {
                    is PrintResult.Success -> _statusBanner.value = "Printed to Bluetooth!"
                    is PrintResult.Failure -> _statusBanner.value = "Print: ${res.error}"
                }
            }
        } else {
            _statusBanner.value = "No Bluetooth printer configured. Open Settings to select a printer."
            openDialog(ActiveDialog.Settings)
        }
    }

    private fun sendToBluetoothIfConfigured(bytes: ByteArray) {
        val address = _settings.value.bluetoothDeviceAddress
        if (address.isNotBlank()) {
            viewModelScope.launch {
                val res = bluetoothPrintManager.printBytes(bytes, address)
                if (res is PrintResult.Failure) {
                    _statusBanner.value = res.error
                }
            }
        }
    }

    fun saveSettings(newSettings: PosSettings) {
        _settings.value = newSettings
        settingsRepository.saveSettings(newSettings)
        _statusBanner.value = "Settings saved successfully."
    }

    // Category CRUD
    fun addCategory(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.insertCategory(Category(name = name.trim()))
            _statusBanner.value = "Category '$name' created."
        }
    }

    fun editCategory(category: Category, newName: String) {
        if (newName.isBlank()) return
        viewModelScope.launch {
            val updated = category.copy(name = newName.trim())
            repository.updateCategory(updated)
            if (_selectedCategory.value?.id == category.id) {
                _selectedCategory.value = updated
            }
            _statusBanner.value = "Category updated to '$newName'."
        }
    }

    fun deleteCategory(category: Category) {
        viewModelScope.launch {
            val count = repository.getItemCountForCategory(category.id)
            repository.deleteCategory(category)
            if (_selectedCategory.value?.id == category.id) {
                _selectedCategory.value = null
            }
            _statusBanner.value = "Category '${category.name}' and $count item(s) deleted."
        }
    }

    // Item CRUD (with image and variants)
    fun saveItem(
        id: Long = 0,
        name: String,
        categoryId: Long,
        price: Double,
        imagePath: String,
        variants: List<ItemVariant>
    ) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val variantsStr = variants.toVariantsString()
            if (id == 0L) {
                val newItem = Item(
                    categoryId = categoryId,
                    name = name.trim(),
                    price = price,
                    imagePath = imagePath,
                    variants = variantsStr
                )
                repository.insertItem(newItem)
                _statusBanner.value = "Item '$name' added to menu."
            } else {
                val updated = Item(
                    id = id,
                    categoryId = categoryId,
                    name = name.trim(),
                    price = price,
                    imagePath = imagePath,
                    variants = variantsStr
                )
                repository.updateItem(updated)
                // If item in cart, update cart item references
                _cartItems.value = _cartItems.value.map {
                    if (it.item.id == id) it.copy(item = updated) else it
                }
                _statusBanner.value = "Item '$name' updated."
            }
        }
    }

    fun deleteItem(item: Item) {
        viewModelScope.launch {
            repository.deleteItem(item)
            _cartItems.value = _cartItems.value.filter { it.item.id != item.id }
            _statusBanner.value = "Item '${item.name}' deleted."
        }
    }

    fun setCurrentMainTab(tab: Int) {
        _currentMainTab.value = tab
    }

    fun setOrderFilterDate(filter: OrderFilterDate) {
        _orderFilterDate.value = filter
    }

    fun setOrderSearchQuery(query: String) {
        _orderSearchQuery.value = query
    }

    fun setOrderPaymentFilter(filter: String) {
        _orderPaymentFilter.value = filter
    }

    fun toggleOrderExpanded(orderId: Long) {
        val current = _expandedOrderIds.value.toMutableSet()
        if (current.contains(orderId)) {
            current.remove(orderId)
            _expandedOrderIds.value = current
        } else {
            current.add(orderId)
            _expandedOrderIds.value = current
            if (!_orderItemsCache.value.containsKey(orderId)) {
                viewModelScope.launch {
                    val items = repository.getOrderItemsForOrder(orderId)
                    val map = _orderItemsCache.value.toMutableMap()
                    map[orderId] = items
                    _orderItemsCache.value = map
                }
            }
        }
    }
}
