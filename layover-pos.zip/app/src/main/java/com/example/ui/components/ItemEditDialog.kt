package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.entities.Category
import com.example.data.entities.Item
import com.example.data.entities.ItemVariant

data class FoodPreset(
    val id: String,
    val label: String,
    val emoji: String
)

val FOOD_PRESETS = listOf(
    FoodPreset("preset_burger", "Burger", "🍔"),
    FoodPreset("preset_burger_bbq", "BBQ Burger", "🥓"),
    FoodPreset("preset_sandwich", "Sandwich", "🥪"),
    FoodPreset("preset_pizza_margherita", "Pizza", "🍕"),
    FoodPreset("preset_pizza_pepperoni", "Pepperoni", "🍕"),
    FoodPreset("preset_steak", "Steak", "🥩"),
    FoodPreset("preset_pasta", "Pasta", "🍝"),
    FoodPreset("preset_chicken", "Chicken", "🍗"),
    FoodPreset("preset_fish", "Fish & Chips", "🐟"),
    FoodPreset("preset_fries", "Fries", "🍟"),
    FoodPreset("preset_wings", "Wings", "🍖"),
    FoodPreset("preset_nachos", "Nachos", "🌮"),
    FoodPreset("preset_coffee", "Coffee", "☕"),
    FoodPreset("preset_limeade", "Juice", "🍹"),
    FoodPreset("preset_soda", "Soda", "🥤"),
    FoodPreset("preset_tea", "Iced Tea", "🧋"),
    FoodPreset("preset_cake", "Cake", "🍰"),
    FoodPreset("preset_cheesecake", "Cheesecake", "🧀"),
    FoodPreset("preset_churros", "Dessert", "🍨"),
    FoodPreset("preset_bakery", "Bakery", "🥐")
)

@Composable
fun ItemEditDialog(
    itemToEdit: Item?,
    categories: List<Category>,
    currencySymbol: String,
    defaultCategoryId: Long? = null,
    onCreateNewCategory: ((String) -> Unit)? = null,
    onSave: (
        id: Long,
        name: String,
        categoryId: Long,
        price: Double,
        imagePath: String,
        variants: List<ItemVariant>
    ) -> Unit,
    onDelete: ((Item) -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val isEdit = itemToEdit != null

    var name by remember { mutableStateOf(itemToEdit?.name ?: "") }
    var priceText by remember { mutableStateOf(if (isEdit) itemToEdit!!.price.toString() else "") }
    var selectedCategory by remember {
        mutableStateOf(
            categories.find { it.id == itemToEdit?.categoryId }
                ?: categories.find { it.id == defaultCategoryId }
                ?: categories.firstOrNull()
        )
    }
    var imagePath by remember { mutableStateOf(itemToEdit?.imagePath ?: "preset_burger") }
    var categoryDropdownExpanded by remember { mutableStateOf(false) }
    var isAddingNewCategoryInline by remember { mutableStateOf(false) }
    var newCategoryInlineName by remember { mutableStateOf("") }

    // Variants State
    var hasVariants by remember { mutableStateOf(itemToEdit?.hasVariants ?: false) }
    val variantsList = remember {
        mutableStateListOf<ItemVariant>().apply {
            if (itemToEdit != null) {
                addAll(itemToEdit.getVariantList())
            }
        }
    }

    var showDeleteConfirm by remember { mutableStateOf(false) }

    // Android Photo Picker launcher (zero-permission media picker)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let {
            imagePath = it.toString()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isEdit) "Edit Menu Item" else "Add New Menu Item",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
                if (isEdit && onDelete != null) {
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete item",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Photo / Image Selection Section
                Text(
                    text = "Item Photo / Avatar (Layover POS Style)",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Photo Preview Box
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (imagePath.startsWith("content://") || imagePath.startsWith("file://") || imagePath.startsWith("http")) {
                            AsyncImage(
                                model = imagePath,
                                contentDescription = "Item Photo",
                                modifier = Modifier.fillMaxWidth(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            val preset = FOOD_PRESETS.find { it.id == imagePath }
                            Text(
                                text = preset?.emoji ?: "🍔",
                                fontSize = 34.sp
                            )
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.AddAPhoto, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Choose from Gallery")
                        }

                        if (imagePath.startsWith("content://") || imagePath.startsWith("file://")) {
                            TextButton(
                                onClick = { imagePath = "preset_burger" },
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text("Reset to Preset", fontSize = 12.sp)
                            }
                        }
                    }
                }

                // Food Presets Horizontal Strip
                Text(text = "Or pick preset food icon:", style = MaterialTheme.typography.labelSmall)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FOOD_PRESETS.forEach { preset ->
                        val isSelected = imagePath == preset.id
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (isSelected) CardDefaults.outlinedCardBorder() else null,
                            modifier = Modifier
                                .clickable { imagePath = preset.id }
                                .padding(2.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(preset.emoji, fontSize = 18.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = preset.label,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                )
                            }
                        }
                    }
                }

                HorizontalDivider()

                // Basic Info: Name, Category, Price
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Item / Food Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_item_name")
                )

                // Category Dropdown
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Category", style = MaterialTheme.typography.labelMedium)
                    if (onCreateNewCategory != null) {
                        TextButton(
                            onClick = { isAddingNewCategoryInline = !isAddingNewCategoryInline },
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text(
                                text = if (isAddingNewCategoryInline) "Choose Existing" else "+ New Category",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                if (isAddingNewCategoryInline) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newCategoryInlineName,
                            onValueChange = { newCategoryInlineName = it },
                            placeholder = { Text("Category name...") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                if (newCategoryInlineName.isNotBlank()) {
                                    onCreateNewCategory?.invoke(newCategoryInlineName.trim())
                                    newCategoryInlineName = ""
                                    isAddingNewCategoryInline = false
                                }
                            },
                            enabled = newCategoryInlineName.isNotBlank()
                        ) {
                            Text("Add")
                        }
                    }
                } else {
                    Box {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { categoryDropdownExpanded = true },
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(selectedCategory?.name ?: "Select Category")
                            Text("▼", color = MaterialTheme.colorScheme.primary)
                        }
                    }

                    DropdownMenu(
                        expanded = categoryDropdownExpanded,
                        onDismissRequest = { categoryDropdownExpanded = false }
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat.name) },
                                onClick = {
                                    selectedCategory = cat
                                    categoryDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }

                // Base Price Field
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text(if (hasVariants) "Base Price (e.g. from)" else "Price") },
                    prefix = { Text(currencySymbol) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_item_price")
                )

                HorizontalDivider()

                // Variants Section (Sizes / Options)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Item Variants / Sizes",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "e.g. Small / Medium / Large with custom prices",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = hasVariants,
                        onCheckedChange = {
                            hasVariants = it
                            if (it && variantsList.isEmpty()) {
                                val baseP = priceText.toDoubleOrNull() ?: 10.0
                                variantsList.add(ItemVariant("Regular", baseP))
                                variantsList.add(ItemVariant("Large", baseP + 3.0))
                            }
                        }
                    )
                }

                if (hasVariants) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                RoundedCornerShape(10.dp)
                            )
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "Configured Variants (${variantsList.size}):",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                        )

                        variantsList.forEachIndexed { index, variant ->
                            var vName by remember(variant) { mutableStateOf(variant.name) }
                            var vPrice by remember(variant) { mutableStateOf(variant.price.toString()) }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = vName,
                                    onValueChange = {
                                        vName = it
                                        val p = vPrice.toDoubleOrNull() ?: variant.price
                                        variantsList[index] = ItemVariant(it, p)
                                    },
                                    placeholder = { Text("Size / Option") },
                                    modifier = Modifier.weight(1.3f),
                                    singleLine = true
                                )

                                OutlinedTextField(
                                    value = vPrice,
                                    onValueChange = {
                                        vPrice = it
                                        val p = it.toDoubleOrNull() ?: 0.0
                                        variantsList[index] = ItemVariant(vName, p)
                                    },
                                    prefix = { Text(currencySymbol) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )

                                IconButton(
                                    onClick = { variantsList.removeAt(index) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Remove variant",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }

                        // Quick suggestion pills for variants
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val baseP = priceText.toDoubleOrNull() ?: 5.0
                            listOf("Small", "Medium", "Large", "Single", "Double", "Spicy", "Extra Cheese").forEach { suggestion ->
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    modifier = Modifier.clickable {
                                        variantsList.add(ItemVariant(suggestion, baseP))
                                    }
                                ) {
                                    Text(
                                        text = "+ $suggestion",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = {
                                val baseP = priceText.toDoubleOrNull() ?: 0.0
                                variantsList.add(ItemVariant("Option ${variantsList.size + 1}", baseP))
                            },
                            modifier = Modifier.align(Alignment.End),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Variant Option")
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val price = priceText.toDoubleOrNull() ?: 0.0
                    val catId = selectedCategory?.id ?: 1L
                    val finalVariants = if (hasVariants) variantsList.filter { it.name.isNotBlank() } else emptyList()
                    onSave(
                        itemToEdit?.id ?: 0L,
                        name.trim(),
                        catId,
                        price,
                        imagePath,
                        finalVariants
                    )
                },
                enabled = name.isNotBlank() && (priceText.toDoubleOrNull() ?: 0.0) > 0.0,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("btn_save_item")
            ) {
                Text(if (isEdit) "Update Item" else "Save Item")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )

    // Delete item confirmation dialog
    if (showDeleteConfirm && itemToEdit != null && onDelete != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete '${itemToEdit.name}'?") },
            text = { Text("Are you sure you want to delete this menu item? It will be removed from your catalog.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDelete(itemToEdit)
                        showDeleteConfirm = false
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
