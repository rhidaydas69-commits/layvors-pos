package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CartPanel
import com.example.ui.components.CategoryTabs
import com.example.ui.components.ItemCard
import com.example.ui.components.ItemEditDialog
import com.example.ui.components.ManageCategoriesDialog
import com.example.ui.components.OrdersHistoryDialog
import com.example.ui.components.PaymentDialog
import com.example.ui.components.ReceiptPreviewDialog
import com.example.ui.components.RecentOrdersPanel
import com.example.ui.components.SettingsDialog
import com.example.ui.components.VariantSelectionDialog
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PosScreen(
    viewModel: PosViewModel,
    modifier: Modifier = Modifier
) {
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val allItems by viewModel.allItems.collectAsStateWithLifecycle()
    val categoryItemCounts by viewModel.categoryItemCounts.collectAsStateWithLifecycle()
    val filteredItems by viewModel.filteredItems.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val orderType by viewModel.orderType.collectAsStateWithLifecycle()
    val tableNumber by viewModel.tableNumber.collectAsStateWithLifecycle()
    val discountPercent by viewModel.discountPercent.collectAsStateWithLifecycle()
    val subtotal by viewModel.subtotal.collectAsStateWithLifecycle()
    val discountAmount by viewModel.discountAmount.collectAsStateWithLifecycle()
    val taxAmount by viewModel.taxAmount.collectAsStateWithLifecycle()
    val grandTotal by viewModel.grandTotal.collectAsStateWithLifecycle()

    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val activeDialog by viewModel.activeDialog.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
    val pairedPrinters by viewModel.pairedPrinters.collectAsStateWithLifecycle()

    // Recent Orders & Daily Sales states
    val currentMainTab by viewModel.currentMainTab.collectAsStateWithLifecycle()
    val filteredRecentOrders by viewModel.filteredRecentOrders.collectAsStateWithLifecycle()
    val dailySalesSummary by viewModel.dailySalesSummary.collectAsStateWithLifecycle()
    val orderFilterDate by viewModel.orderFilterDate.collectAsStateWithLifecycle()
    val orderSearchQuery by viewModel.orderSearchQuery.collectAsStateWithLifecycle()
    val orderPaymentFilter by viewModel.orderPaymentFilter.collectAsStateWithLifecycle()
    val expandedOrderIds by viewModel.expandedOrderIds.collectAsStateWithLifecycle()
    val orderItemsCache by viewModel.orderItemsCache.collectAsStateWithLifecycle()
    val todayRevenue by viewModel.todayRevenue.collectAsStateWithLifecycle()

    var mobileActiveTab by remember { mutableIntStateOf(0) } // 0 = Menu, 1 = Cart, 2 = Recent Orders

    // Back button handling to return to Register screen
    BackHandler(enabled = currentMainTab != 0 || mobileActiveTab != 0) {
        if (currentMainTab != 0) {
            viewModel.setCurrentMainTab(0)
        }
        if (mobileActiveTab != 0) {
            mobileActiveTab = 0
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Fastfood,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = settings.restaurantName,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(7.dp)
                                ) {}
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Offline Mode • ${settings.paperSize.label}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                },
                actions = {
                    // Quick Action: Add custom item
                    IconButton(
                        onClick = { viewModel.openDialog(ActiveDialog.AddOrEditItem(defaultCategoryId = selectedCategory?.id)) },
                        modifier = Modifier.testTag("action_add_item")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add Item")
                    }

                    // Settings modal
                    IconButton(
                        onClick = { viewModel.openDialog(ActiveDialog.Settings) },
                        modifier = Modifier.testTag("action_settings")
                    ) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Status banner for print/action notifications
            AnimatedVisibility(visible = statusBanner != null) {
                statusBanner?.let { message ->
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = message,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            IconButton(
                                onClick = { viewModel.dismissBanner() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dismiss",
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val isTabletOrLandscape = maxWidth >= 700.dp

                if (isTabletOrLandscape) {
                    // Tablet / Desktop Landscape View
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Tablet Workspace Mode Switcher: POS Register vs Recent Orders & Sales
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            tonalElevation = 2.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (currentMainTab == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier
                                            .clickable { viewModel.setCurrentMainTab(0) }
                                            .testTag("tablet_tab_register")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.PointOfSale,
                                                contentDescription = null,
                                                tint = if (currentMainTab == 0) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "POS Register",
                                                style = MaterialTheme.typography.labelLarge.copy(
                                                    fontWeight = if (currentMainTab == 0) FontWeight.Bold else FontWeight.Medium
                                                ),
                                                color = if (currentMainTab == 0) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (currentMainTab == 1) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier
                                            .clickable { viewModel.setCurrentMainTab(1) }
                                            .testTag("tablet_tab_recent_orders")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.TrendingUp,
                                                contentDescription = null,
                                                tint = if (currentMainTab == 1) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "Recent Orders & Daily Sales",
                                                style = MaterialTheme.typography.labelLarge.copy(
                                                    fontWeight = if (currentMainTab == 1) FontWeight.Bold else FontWeight.Medium
                                                ),
                                                color = if (currentMainTab == 1) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                shape = CircleShape,
                                                color = if (currentMainTab == 1) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.primaryContainer
                                            ) {
                                                Text(
                                                    text = "${orders.size}",
                                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                    color = if (currentMainTab == 1) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onPrimaryContainer,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }

                                // Quick Stat in tablet bar
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Today's Sales: ",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "${settings.currencySymbol}${String.format(Locale.US, "%.2f", todayRevenue)}",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                    )
                                }
                            }
                        }

                        if (currentMainTab == 0) {
                            // Split-Screen Layout (Left: Menu 60%, Right: Billing Cart 40%)
                            Row(modifier = Modifier.fillMaxSize()) {
                                // Left Panel: Menu & Food Items Grid
                                Column(
                                    modifier = Modifier
                                        .weight(1.3f)
                                        .fillMaxHeight()
                                ) {
                                    // Search Bar
                                    OutlinedTextField(
                                        value = searchQuery,
                                        onValueChange = { viewModel.setSearchQuery(it) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                            .testTag("menu_search_bar"),
                                        placeholder = { Text("Search food or drink...") },
                                        leadingIcon = {
                                            Icon(imageVector = Icons.Default.Search, contentDescription = "Search")
                                        },
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp)
                                    )

                                    // Category Tabs
                                    CategoryTabs(
                                        categories = categories,
                                        selectedCategory = selectedCategory,
                                        itemCounts = categoryItemCounts,
                                        totalItemCount = allItems.size,
                                        onSelectCategory = { viewModel.selectCategory(it) },
                                        onManageCategories = { viewModel.openDialog(ActiveDialog.ManageCategories) }
                                    )

                                    // Items Grid or Empty State
                                    if (filteredItems.isEmpty()) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .padding(24.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Fastfood,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(56.dp),
                                                    tint = MaterialTheme.colorScheme.outline
                                                )
                                                Spacer(modifier = Modifier.height(12.dp))
                                                Text(
                                                    text = if (selectedCategory != null) "No items in '${selectedCategory?.name}'" else "No menu items found",
                                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Text(
                                                    text = if (searchQuery.isNotBlank()) "Try a different search keyword" else "Tap below to add food items to this category",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.outline
                                                )
                                                Spacer(modifier = Modifier.height(14.dp))
                                                androidx.compose.material3.Button(
                                                    onClick = {
                                                        viewModel.openDialog(ActiveDialog.AddOrEditItem(defaultCategoryId = selectedCategory?.id))
                                                    },
                                                    shape = RoundedCornerShape(10.dp)
                                                ) {
                                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(if (selectedCategory != null) "Add Item to ${selectedCategory?.name}" else "Add Menu Item")
                                                }
                                            }
                                        }
                                    } else {
                                        LazyVerticalGrid(
                                            columns = GridCells.Adaptive(minSize = 140.dp),
                                            contentPadding = PaddingValues(12.dp),
                                            verticalArrangement = Arrangement.spacedBy(10.dp),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .testTag("items_grid")
                                        ) {
                                            items(filteredItems, key = { it.id }) { item ->
                                                ItemCard(
                                                    item = item,
                                                    currencySymbol = settings.currencySymbol,
                                                    onAddToCart = { viewModel.addToCart(it) },
                                                    onEditItem = { viewModel.openDialog(ActiveDialog.AddOrEditItem(it)) }
                                                )
                                            }
                                        }
                                    }
                                }

                                // Right Panel: Billing Cart
                                CartPanel(
                                    cartItems = cartItems,
                                    subtotal = subtotal,
                                    discountAmount = discountAmount,
                                    discountPercent = discountPercent,
                                    taxAmount = taxAmount,
                                    taxRate = settings.taxRate,
                                    grandTotal = grandTotal,
                                    currencySymbol = settings.currencySymbol,
                                    orderType = orderType,
                                    tableNumber = tableNumber,
                                    onSelectOrderType = { viewModel.setOrderType(it) },
                                    onSelectTable = { viewModel.setTableNumber(it) },
                                    onIncrement = { viewModel.incrementCartItem(it) },
                                    onDecrement = { viewModel.decrementCartItem(it) },
                                    onRemove = { viewModel.removeCartItem(it) },
                                    onClearCart = { viewModel.clearCart() },
                                    onSetDiscountPercent = { viewModel.setDiscountPercent(it) },
                                    onPrintKot = { viewModel.printKot() },
                                    onCompletePayment = { viewModel.openDialog(ActiveDialog.Payment) },
                                    modifier = Modifier
                                        .weight(0.9f)
                                        .fillMaxHeight()
                                        .testTag("cart_panel")
                                )
                            }
                        } else {
                            // Recent Orders & Daily Sales Panel
                            RecentOrdersPanel(
                                orders = filteredRecentOrders,
                                salesSummary = dailySalesSummary,
                                selectedDateFilter = orderFilterDate,
                                searchQuery = orderSearchQuery,
                                paymentFilter = orderPaymentFilter,
                                expandedOrderIds = expandedOrderIds,
                                orderItemsCache = orderItemsCache,
                                currencySymbol = settings.currencySymbol,
                                onSelectDateFilter = { viewModel.setOrderFilterDate(it) },
                                onSearchQueryChange = { viewModel.setOrderSearchQuery(it) },
                                onSelectPaymentFilter = { viewModel.setOrderPaymentFilter(it) },
                                onToggleExpandOrder = { viewModel.toggleOrderExpanded(it) },
                                onReprintReceipt = { viewModel.reprintOrder(it, isKot = false) },
                                onReprintKot = { viewModel.reprintOrder(it, isKot = true) },
                                modifier = Modifier
                                    .fillMaxSize()
                                    .testTag("recent_orders_panel_tablet")
                            )
                        }
                    }
                } else {
                    // Mobile / Handheld POS Device (e.g., Sunmi V2) Layout with 3 Tabs
                    Column(modifier = Modifier.fillMaxSize()) {
                        TabRow(
                            selectedTabIndex = mobileActiveTab,
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            Tab(
                                selected = mobileActiveTab == 0,
                                onClick = { mobileActiveTab = 0 },
                                text = { Text("Menu Grid") },
                                icon = { Icon(Icons.Default.Fastfood, contentDescription = null) }
                            )
                            Tab(
                                selected = mobileActiveTab == 1,
                                onClick = { mobileActiveTab = 1 },
                                text = {
                                    val count = cartItems.sumOf { it.quantity }
                                    Text(if (count > 0) "Order ($count)" else "Billing Cart")
                                },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            val count = cartItems.sumOf { it.quantity }
                                            if (count > 0) Badge { Text("$count") }
                                        }
                                    ) {
                                        Icon(Icons.Default.ShoppingBag, contentDescription = null)
                                    }
                                }
                            )
                            Tab(
                                selected = mobileActiveTab == 2,
                                onClick = { mobileActiveTab = 2 },
                                text = { Text("Recent Orders") },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (orders.isNotEmpty()) {
                                                Badge { Text("${orders.size}") }
                                            }
                                        }
                                    ) {
                                        Icon(Icons.Default.TrendingUp, contentDescription = null)
                                    }
                                }
                            )
                        }

                        when (mobileActiveTab) {
                            0 -> {
                                // Mobile Menu Tab
                                Column(modifier = Modifier.fillMaxSize()) {
                                    OutlinedTextField(
                                        value = searchQuery,
                                        onValueChange = { viewModel.setSearchQuery(it) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                            .testTag("menu_search_bar_mobile"),
                                        placeholder = { Text("Search items...") },
                                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp)
                                    )

                                    CategoryTabs(
                                        categories = categories,
                                        selectedCategory = selectedCategory,
                                        onSelectCategory = { viewModel.selectCategory(it) },
                                        onManageCategories = { viewModel.openDialog(ActiveDialog.ManageCategories) }
                                    )

                                    Box(modifier = Modifier.weight(1f)) {
                                        LazyVerticalGrid(
                                            columns = GridCells.Fixed(2),
                                            contentPadding = PaddingValues(10.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.fillMaxSize()
                                        ) {
                                            items(filteredItems, key = { it.id }) { item ->
                                                ItemCard(
                                                    item = item,
                                                    currencySymbol = settings.currencySymbol,
                                                    onAddToCart = { viewModel.addToCart(it) },
                                                    onEditItem = { viewModel.openDialog(ActiveDialog.AddOrEditItem(it)) }
                                                )
                                            }
                                        }

                                        // Floating Bottom Bar when items are in cart
                                        if (cartItems.isNotEmpty()) {
                                            Surface(
                                                modifier = Modifier
                                                    .align(Alignment.BottomCenter)
                                                    .fillMaxWidth()
                                                    .padding(12.dp)
                                                    .clickable { mobileActiveTab = 1 },
                                                shape = RoundedCornerShape(14.dp),
                                                color = MaterialTheme.colorScheme.primary,
                                                tonalElevation = 6.dp
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column {
                                                        Text(
                                                            text = "${cartItems.sumOf { it.quantity }} items selected",
                                                            style = MaterialTheme.typography.bodySmall,
                                                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
                                                        )
                                                        Text(
                                                            text = "${settings.currencySymbol}${String.format(Locale.US, "%.2f", grandTotal)}",
                                                            style = MaterialTheme.typography.titleMedium.copy(
                                                                fontWeight = FontWeight.Bold,
                                                                color = MaterialTheme.colorScheme.onPrimary
                                                            )
                                                        )
                                                    }
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Text(
                                                            text = "View Bill & Pay",
                                                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                                            color = MaterialTheme.colorScheme.onPrimary
                                                        )
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Icon(
                                                            imageVector = Icons.Default.ShoppingBag,
                                                            contentDescription = null,
                                                            tint = MaterialTheme.colorScheme.onPrimary
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            1 -> {
                                // Mobile Billing Cart Tab
                                CartPanel(
                                    cartItems = cartItems,
                                    subtotal = subtotal,
                                    discountAmount = discountAmount,
                                    discountPercent = discountPercent,
                                    taxAmount = taxAmount,
                                    taxRate = settings.taxRate,
                                    grandTotal = grandTotal,
                                    currencySymbol = settings.currencySymbol,
                                    orderType = orderType,
                                    tableNumber = tableNumber,
                                    onSelectOrderType = { viewModel.setOrderType(it) },
                                    onSelectTable = { viewModel.setTableNumber(it) },
                                    onIncrement = { viewModel.incrementCartItem(it) },
                                    onDecrement = { viewModel.decrementCartItem(it) },
                                    onRemove = { viewModel.removeCartItem(it) },
                                    onClearCart = { viewModel.clearCart() },
                                    onSetDiscountPercent = { viewModel.setDiscountPercent(it) },
                                    onPrintKot = { viewModel.printKot() },
                                    onCompletePayment = { viewModel.openDialog(ActiveDialog.Payment) },
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag("cart_panel_mobile")
                                )
                            }
                            2 -> {
                                // Mobile Recent Orders & Daily Sales Tab
                                RecentOrdersPanel(
                                    orders = filteredRecentOrders,
                                    salesSummary = dailySalesSummary,
                                    selectedDateFilter = orderFilterDate,
                                    searchQuery = orderSearchQuery,
                                    paymentFilter = orderPaymentFilter,
                                    expandedOrderIds = expandedOrderIds,
                                    orderItemsCache = orderItemsCache,
                                    currencySymbol = settings.currencySymbol,
                                    onSelectDateFilter = { viewModel.setOrderFilterDate(it) },
                                    onSearchQueryChange = { viewModel.setOrderSearchQuery(it) },
                                    onSelectPaymentFilter = { viewModel.setOrderPaymentFilter(it) },
                                    onToggleExpandOrder = { viewModel.toggleOrderExpanded(it) },
                                    onReprintReceipt = { viewModel.reprintOrder(it, isKot = false) },
                                    onReprintKot = { viewModel.reprintOrder(it, isKot = true) },
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag("recent_orders_panel_mobile")
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Active Dialogs Handling
    when (val dialog = activeDialog) {
        is ActiveDialog.Payment -> {
            PaymentDialog(
                grandTotal = grandTotal,
                currencySymbol = settings.currencySymbol,
                onConfirm = { method, tendered ->
                    viewModel.completePayment(method, tendered)
                },
                onDismiss = { viewModel.closeDialog() }
            )
        }
        is ActiveDialog.Settings -> {
            SettingsDialog(
                currentSettings = settings,
                pairedPrinters = pairedPrinters,
                onRefreshPrinters = { viewModel.refreshPairedPrinters() },
                onSave = {
                    viewModel.saveSettings(it)
                    viewModel.closeDialog()
                },
                onDismiss = { viewModel.closeDialog() }
            )
        }
        is ActiveDialog.ReceiptPreview -> {
            ReceiptPreviewDialog(
                title = dialog.title,
                receiptText = dialog.receiptText,
                rawBytesCount = dialog.rawBytes.size,
                isKot = dialog.isKot,
                onPrintViaBluetooth = {
                    viewModel.printRawBytes(dialog.rawBytes)
                },
                onDismiss = { viewModel.closeDialog() }
            )
        }
        is ActiveDialog.OrderHistory -> {
            OrdersHistoryDialog(
                orders = orders,
                currencySymbol = settings.currencySymbol,
                onReprintBill = { viewModel.reprintOrder(it, isKot = false) },
                onReprintKot = { viewModel.reprintOrder(it, isKot = true) },
                onDismiss = { viewModel.closeDialog() }
            )
        }
        is ActiveDialog.AddOrEditItem -> {
            ItemEditDialog(
                itemToEdit = dialog.itemToEdit,
                categories = categories,
                currencySymbol = settings.currencySymbol,
                onSave = { id, name, catId, price, imagePath, variants ->
                    viewModel.saveItem(id, name, catId, price, imagePath, variants)
                    viewModel.closeDialog()
                },
                onDelete = { item ->
                    viewModel.deleteItem(item)
                    viewModel.closeDialog()
                },
                onDismiss = { viewModel.closeDialog() }
            )
        }
        is ActiveDialog.ManageCategories -> {
            ManageCategoriesDialog(
                categories = categories,
                onAddCategory = { viewModel.addCategory(it) },
                onEditCategory = { cat, newName -> viewModel.editCategory(cat, newName) },
                onDeleteCategory = { viewModel.deleteCategory(it) },
                onDismiss = { viewModel.closeDialog() }
            )
        }
        is ActiveDialog.SelectVariant -> {
            VariantSelectionDialog(
                item = dialog.item,
                currencySymbol = settings.currencySymbol,
                onSelectVariant = { variant ->
                    viewModel.addToCart(dialog.item, variant)
                    viewModel.closeDialog()
                },
                onDismiss = { viewModel.closeDialog() }
            )
        }
        null -> {}
    }
}
