package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.PaperSize
import com.example.data.PosSettings
import com.example.printer.PairedPrinterDevice

@Composable
fun SettingsDialog(
    currentSettings: PosSettings,
    pairedPrinters: List<PairedPrinterDevice>,
    onRefreshPrinters: () -> Unit,
    onSave: (PosSettings) -> Unit,
    onDismiss: () -> Unit
) {
    var restaurantName by remember { mutableStateOf(currentSettings.restaurantName) }
    var address by remember { mutableStateOf(currentSettings.address) }
    var phone by remember { mutableStateOf(currentSettings.phone) }
    var taxRateText by remember { mutableStateOf(currentSettings.taxRate.toString()) }
    var currencySymbol by remember { mutableStateOf(currentSettings.currencySymbol) }
    var paperSize by remember { mutableStateOf(currentSettings.paperSize) }
    var footerMessage by remember { mutableStateOf(currentSettings.footerMessage) }
    var selectedBtAddress by remember { mutableStateOf(currentSettings.bluetoothDeviceAddress) }

    var printerDropdownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Store,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Restaurant & Printer Settings",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Receipt Header Information",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )

                OutlinedTextField(
                    value = restaurantName,
                    onValueChange = { restaurantName = it },
                    label = { Text("Restaurant Name") },
                    modifier = Modifier.fillMaxWidth().testTag("input_rest_name"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Address") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = taxRateText,
                        onValueChange = { taxRateText = it },
                        label = { Text("Tax / VAT %") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = currencySymbol,
                        onValueChange = { currencySymbol = it },
                        label = { Text("Currency") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                Text(
                    text = "Thermal Printer Settings",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )

                // Paper Size Selector (58mm vs 80mm)
                Text(text = "Paper Width Format", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { paperSize = PaperSize.MM_58 }
                    ) {
                        RadioButton(
                            selected = paperSize == PaperSize.MM_58,
                            onClick = { paperSize = PaperSize.MM_58 }
                        )
                        Text("58mm (Handheld/Sunmi)")
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { paperSize = PaperSize.MM_80 }
                    ) {
                        RadioButton(
                            selected = paperSize == PaperSize.MM_80,
                            onClick = { paperSize = PaperSize.MM_80 }
                        )
                        Text("80mm (Desktop POS)")
                    }
                }

                // Bluetooth Printer Selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Bluetooth, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Bluetooth Thermal Printer", style = MaterialTheme.typography.labelMedium)
                    }
                    IconButton(onClick = onRefreshPrinters, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "Scan printers", modifier = Modifier.size(18.dp))
                    }
                }

                Box {
                    val selectedDeviceName = pairedPrinters.find { it.address == selectedBtAddress }?.name
                        ?: if (selectedBtAddress.isBlank()) "None (Preview Only)" else selectedBtAddress

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { printerDropdownExpanded = true },
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = selectedDeviceName, style = MaterialTheme.typography.bodyMedium)
                            Text(text = "Choose ▼", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                    }

                    DropdownMenu(
                        expanded = printerDropdownExpanded,
                        onDismissRequest = { printerDropdownExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("None (Screen Preview Mode)") },
                            onClick = {
                                selectedBtAddress = ""
                                printerDropdownExpanded = false
                            }
                        )
                        pairedPrinters.forEach { device ->
                            DropdownMenuItem(
                                text = { Text("${device.name} (${device.address})") },
                                onClick = {
                                    selectedBtAddress = device.address
                                    printerDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = footerMessage,
                    onValueChange = { footerMessage = it },
                    label = { Text("Receipt Footer Message") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val rate = taxRateText.toDoubleOrNull() ?: 0.0
                    onSave(
                        currentSettings.copy(
                            restaurantName = restaurantName.trim(),
                            address = address.trim(),
                            phone = phone.trim(),
                            taxRate = rate,
                            currencySymbol = currencySymbol.trim(),
                            paperSize = paperSize,
                            footerMessage = footerMessage.trim(),
                            bluetoothDeviceAddress = selectedBtAddress
                        )
                    )
                },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("btn_save_settings")
            ) {
                Text("Save Settings")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
