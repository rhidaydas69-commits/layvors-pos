package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary POS Palette: Warm Amber & Deep Slate Navy
val AmberPrimary = Color(0xFFD97706)
val AmberSecondary = Color(0xFFB45309)
val AmberTertiary = Color(0xFFF59E0B)

val SlateDarkBackground = Color(0xFF0F172A)
val SlateDarkSurface = Color(0xFF1E293B)
val SlateDarkSurfaceVariant = Color(0xFF334155)
val SlateDarkOutline = Color(0xFF475569)

val PosSuccessGreen = Color(0xFF10B981)
val PosInfoBlue = Color(0xFF0284C7)
val PosAlertRed = Color(0xFFEF4444)

val SlateLightBackground = Color(0xFFF8FAFC)
val SlateLightSurface = Color(0xFFFFFFFF)
val SlateLightSurfaceVariant = Color(0xFFF1F5F9)
val SlateLightOutline = Color(0xFFCBD5E1)
