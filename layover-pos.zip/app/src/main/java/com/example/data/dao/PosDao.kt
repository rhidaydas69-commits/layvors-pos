package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.entities.Category
import com.example.data.entities.Item
import com.example.data.entities.Order
import com.example.data.entities.OrderItem
import kotlinx.coroutines.flow.Flow

data class OrderWithItems(
    val order: Order,
    val items: List<OrderItem>
)

@Dao
interface PosDao {

    // Categories
    @Query("SELECT * FROM categories ORDER BY id ASC")
    fun getAllCategories(): Flow<List<Category>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: Category): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategories(categories: List<Category>): List<Long>

    @Update
    suspend fun updateCategory(category: Category)

    @Delete
    suspend fun deleteCategory(category: Category)

    @Query("DELETE FROM categories WHERE id = :categoryId")
    suspend fun deleteCategory(categoryId: Long)

    @Query("SELECT COUNT(*) FROM items WHERE category_id = :categoryId")
    suspend fun getItemCountForCategory(categoryId: Long): Int

    // Items
    @Query("SELECT * FROM items ORDER BY name ASC")
    fun getAllItems(): Flow<List<Item>>

    @Query("SELECT * FROM items WHERE category_id = :categoryId ORDER BY name ASC")
    fun getItemsByCategory(categoryId: Long): Flow<List<Item>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: Item): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<Item>): List<Long>

    @Update
    suspend fun updateItem(item: Item)

    @Delete
    suspend fun deleteItem(item: Item)

    @Query("DELETE FROM items WHERE id = :itemId")
    suspend fun deleteItemById(itemId: Long)

    // Orders
    @Query("SELECT * FROM orders ORDER BY id DESC")
    fun getAllOrders(): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE id = :orderId")
    suspend fun getOrderById(orderId: Long): Order?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order): Long

    // Order Items
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderItems(items: List<OrderItem>)

    @Query("SELECT * FROM order_items WHERE order_id = :orderId ORDER BY id ASC")
    suspend fun getOrderItemsForOrder(orderId: Long): List<OrderItem>

    @Query("SELECT * FROM order_items WHERE order_id = :orderId ORDER BY id ASC")
    fun getOrderItemsFlow(orderId: Long): Flow<List<OrderItem>>

    @Transaction
    suspend fun createOrderWithItems(order: Order, items: List<OrderItem>): Long {
        val orderId = insertOrder(order)
        val linkedItems = items.map { it.copy(orderId = orderId) }
        insertOrderItems(linkedItems)
        return orderId
    }

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun getCategoryCount(): Int

    @Query("SELECT COUNT(*) FROM items")
    suspend fun getItemCount(): Int

    @Query("DELETE FROM items WHERE category_id = :categoryId")
    suspend fun deleteItemsByCategoryId(categoryId: Long)

    @Transaction
    suspend fun deleteCategoryAndItems(categoryId: Long) {
        deleteItemsByCategoryId(categoryId)
        deleteCategory(categoryId)
    }
}
