package com.example.data

import com.example.data.dao.PosDao
import com.example.data.entities.Category
import com.example.data.entities.Item
import com.example.data.entities.Order
import com.example.data.entities.OrderItem
import kotlinx.coroutines.flow.Flow

class PosRepository(private val posDao: PosDao) {

    val allCategories: Flow<List<Category>> = posDao.getAllCategories()
    val allItems: Flow<List<Item>> = posDao.getAllItems()
    val allOrders: Flow<List<Order>> = posDao.getAllOrders()

    fun getItemsByCategory(categoryId: Long): Flow<List<Item>> {
        return if (categoryId <= 0) {
            posDao.getAllItems()
        } else {
            posDao.getItemsByCategory(categoryId)
        }
    }

    suspend fun insertItem(item: Item): Long = posDao.insertItem(item)

    suspend fun updateItem(item: Item) = posDao.updateItem(item)

    suspend fun deleteItem(item: Item) = posDao.deleteItem(item)

    suspend fun insertCategory(category: Category): Long = posDao.insertCategory(category)

    suspend fun updateCategory(category: Category) = posDao.updateCategory(category)

    suspend fun deleteCategory(category: Category) = posDao.deleteCategoryAndItems(category.id)

    suspend fun getItemCountForCategory(categoryId: Long): Int = posDao.getItemCountForCategory(categoryId)

    suspend fun createOrder(order: Order, items: List<OrderItem>): Long {
        return posDao.createOrderWithItems(order, items)
    }

    suspend fun getOrderById(orderId: Long): Order? = posDao.getOrderById(orderId)

    suspend fun getOrderItemsForOrder(orderId: Long): List<OrderItem> =
        posDao.getOrderItemsForOrder(orderId)
}
