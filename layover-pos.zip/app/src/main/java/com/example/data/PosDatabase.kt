package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.PosDao
import com.example.data.entities.Category
import com.example.data.entities.Item
import com.example.data.entities.Order
import com.example.data.entities.OrderItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Category::class, Item::class, Order::class, OrderItem::class],
    version = 2,
    exportSchema = false
)
abstract class PosDatabase : RoomDatabase() {

    abstract fun posDao(): PosDao

    companion object {
        @Volatile
        private var INSTANCE: PosDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): PosDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PosDatabase::class.java,
                    "layover_pos_room.db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(PosDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        suspend fun populateInitialData(dao: PosDao) {
            if (dao.getCategoryCount() > 0 && dao.getItemCount() > 0) return

            val catBurgers = Category(name = "Burgers")
            val catPizzas = Category(name = "Pizzas")
            val catMains = Category(name = "Mains")
            val catStarters = Category(name = "Starters")
            val catBeverages = Category(name = "Beverages")
            val catDesserts = Category(name = "Desserts")

            val burgerId = dao.insertCategory(catBurgers)
            val pizzaId = dao.insertCategory(catPizzas)
            val mainId = dao.insertCategory(catMains)
            val starterId = dao.insertCategory(catStarters)
            val bevId = dao.insertCategory(catBeverages)
            val dessertId = dao.insertCategory(catDesserts)

            val initialItems = listOf(
                // Burgers
                Item(categoryId = burgerId, name = "Classic Cheeseburger", price = 8.99, imagePath = "preset_burger", variants = "Single:8.99|Double:11.99|Triple:14.49"),
                Item(categoryId = burgerId, name = "Smoky BBQ Bacon Burger", price = 11.49, imagePath = "preset_burger_bbq", variants = "Regular:11.49|Double Meat:14.49"),
                Item(categoryId = burgerId, name = "Crispy Chicken Sandwich", price = 9.99, imagePath = "preset_sandwich", variants = "Mild:9.99|Spicy:9.99|Extra Crispy:10.99"),
                Item(categoryId = burgerId, name = "Double Truffle Smash Burger", price = 13.99, imagePath = "preset_burger", variants = ""),

                // Pizzas
                Item(categoryId = pizzaId, name = "Margherita Supreme Pizza", price = 12.50, imagePath = "preset_pizza_margherita", variants = "Regular 9\":10.50|Medium 12\":12.50|Large 14\":15.50"),
                Item(categoryId = pizzaId, name = "Pepperoni Feast 12\"", price = 14.99, imagePath = "preset_pizza_pepperoni", variants = "Medium 12\":14.99|Large 14\":18.99|Party 16\":22.99"),
                Item(categoryId = pizzaId, name = "BBQ Chicken & Red Onion", price = 15.50, imagePath = "preset_pizza_bbq", variants = "Medium 12\":15.50|Large 14\":19.50"),
                Item(categoryId = pizzaId, name = "Four Cheese Quattro Formaggi", price = 13.99, imagePath = "preset_pizza_cheese", variants = ""),

                // Mains
                Item(categoryId = mainId, name = "Grilled Ribeye Steak 250g", price = 24.99, imagePath = "preset_steak", variants = "Medium Rare:24.99|Medium:24.99|Well Done:24.99"),
                Item(categoryId = mainId, name = "Creamy Garlic Prawn Pasta", price = 16.50, imagePath = "preset_pasta", variants = "Standard:16.50|Extra Prawns:20.50"),
                Item(categoryId = mainId, name = "Herb Roasted Half Chicken", price = 15.99, imagePath = "preset_chicken", variants = ""),
                Item(categoryId = mainId, name = "Golden Fish & Chips with Tartar", price = 13.99, imagePath = "preset_fish", variants = "Regular:13.99|Large:16.99"),

                // Starters
                Item(categoryId = starterId, name = "Crispy Truffle Fries", price = 5.99, imagePath = "preset_fries", variants = "Regular:5.99|Large:7.99"),
                Item(categoryId = starterId, name = "Spicy Buffalo Wings (8pcs)", price = 8.50, imagePath = "preset_wings", variants = "6 Pcs:6.50|8 Pcs:8.50|12 Pcs:12.00"),
                Item(categoryId = starterId, name = "Mozzarella Sticks & Dip", price = 6.99, imagePath = "preset_mozzarella", variants = ""),
                Item(categoryId = starterId, name = "Loaded Cheesy Nachos", price = 7.99, imagePath = "preset_nachos", variants = "Regular:7.99|Loaded Beef:10.99"),

                // Beverages
                Item(categoryId = bevId, name = "Signature Iced Caramel Latte", price = 4.50, imagePath = "preset_coffee", variants = "Regular (12oz):3.99|Large (16oz):4.50|Venti (20oz):5.25"),
                Item(categoryId = bevId, name = "Fresh Mint Limeade", price = 3.99, imagePath = "preset_limeade", variants = "Glass:3.99|Pitcher:9.99"),
                Item(categoryId = bevId, name = "Craft Draft Soda", price = 2.99, imagePath = "preset_soda", variants = "Can:2.99|Bottle:3.99"),
                Item(categoryId = bevId, name = "Peach Iced Tea", price = 3.75, imagePath = "preset_tea", variants = "Regular:3.75|Large:4.50"),

                // Desserts
                Item(categoryId = dessertId, name = "Warm Molten Lava Cake", price = 6.50, imagePath = "preset_cake", variants = "Classic:6.50|With Vanilla Gelato:7.99"),
                Item(categoryId = dessertId, name = "New York Style Cheesecake", price = 5.99, imagePath = "preset_cheesecake", variants = "Slice:5.99|Whole Cake:32.00"),
                Item(categoryId = dessertId, name = "Churros with Dulce de Leche", price = 5.50, imagePath = "preset_churros", variants = "4 Pcs:5.50|8 Pcs:9.00")
            )

            dao.insertItems(initialItems)

            // Seed initial past orders to demonstrate daily sales tracking
            val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
            val order1 = Order(
                orderDate = "$todayStr 10:15",
                orderType = "Dine-In",
                tableNumber = "Table 2",
                totalAmount = 13.49,
                discount = 0.0,
                netAmount = 14.16,
                paymentMethod = "Cash"
            )
            val items1 = listOf(
                OrderItem(orderId = 0, itemName = "Classic Cheeseburger (Single)", price = 8.99, quantity = 1, total = 8.99),
                OrderItem(orderId = 0, itemName = "Signature Iced Caramel Latte (Large)", price = 4.50, quantity = 1, total = 4.50)
            )
            dao.createOrderWithItems(order1, items1)

            val order2 = Order(
                orderDate = "$todayStr 11:40",
                orderType = "Dine-In",
                tableNumber = "Table 4",
                totalAmount = 26.97,
                discount = 2.00,
                netAmount = 26.22,
                paymentMethod = "Card"
            )
            val items2 = listOf(
                OrderItem(orderId = 0, itemName = "Pepperoni Feast (Medium 12\")", price = 14.99, quantity = 1, total = 14.99),
                OrderItem(orderId = 0, itemName = "Crispy Truffle Fries (Regular)", price = 5.99, quantity = 1, total = 5.99),
                OrderItem(orderId = 0, itemName = "Warm Molten Lava Cake (Classic)", price = 6.50, quantity = 1, total = 6.50)
            )
            dao.createOrderWithItems(order2, items2)
        }
    }

    private class PosDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database.posDao())
                }
            }
        }

        override fun onOpen(db: SupportSQLiteDatabase) {
            super.onOpen(db)
            db.setForeignKeyConstraintsEnabled(true)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    if (database.posDao().getCategoryCount() == 0) {
                        populateInitialData(database.posDao())
                    }
                }
            }
        }
    }
}
