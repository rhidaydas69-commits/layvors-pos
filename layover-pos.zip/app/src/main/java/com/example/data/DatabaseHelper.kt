package com.example.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Native Android SQLiteOpenHelper implementing the offline Restaurant POS database.
 * Exactly adheres to the requested offline POS schema:
 * 1. categories (id, name)
 * 2. items (id, category_id, name, price, image_path)
 * 3. orders (id, order_date, order_type, table_number, total_amount, discount, net_amount, payment_method)
 * 4. order_items (id, order_id, item_name, price, quantity, total)
 */
class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "layover_pos.db"
        const val DATABASE_VERSION = 1

        // Table Names
        const val TABLE_CATEGORIES = "categories"
        const val TABLE_ITEMS = "items"
        const val TABLE_ORDERS = "orders"
        const val TABLE_ORDER_ITEMS = "order_items"

        // Categories columns
        const val COL_CAT_ID = "id"
        const val COL_CAT_NAME = "name"

        // Items columns
        const val COL_ITEM_ID = "id"
        const val COL_ITEM_CAT_ID = "category_id"
        const val COL_ITEM_NAME = "name"
        const val COL_ITEM_PRICE = "price"
        const val COL_ITEM_IMAGE_PATH = "image_path"
        const val COL_ITEM_VARIANTS = "variants"

        // Orders columns
        const val COL_ORDER_ID = "id"
        const val COL_ORDER_DATE = "order_date"
        const val COL_ORDER_TYPE = "order_type"
        const val COL_ORDER_TABLE = "table_number"
        const val COL_ORDER_TOTAL = "total_amount"
        const val COL_ORDER_DISCOUNT = "discount"
        const val COL_ORDER_NET = "net_amount"
        const val COL_ORDER_PAYMENT_METHOD = "payment_method"

        // Order Items columns
        const val COL_OI_ID = "id"
        const val COL_OI_ORDER_ID = "order_id"
        const val COL_OI_ITEM_NAME = "item_name"
        const val COL_OI_PRICE = "price"
        const val COL_OI_QTY = "quantity"
        const val COL_OI_TOTAL = "total"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createCategoriesTable = """
            CREATE TABLE $TABLE_CATEGORIES (
                $COL_CAT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_CAT_NAME TEXT NOT NULL
            );
        """.trimIndent()

        val createItemsTable = """
            CREATE TABLE $TABLE_ITEMS (
                $COL_ITEM_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_ITEM_CAT_ID INTEGER NOT NULL,
                $COL_ITEM_NAME TEXT NOT NULL,
                $COL_ITEM_PRICE REAL NOT NULL,
                $COL_ITEM_IMAGE_PATH TEXT,
                $COL_ITEM_VARIANTS TEXT DEFAULT '',
                FOREIGN KEY ($COL_ITEM_CAT_ID) REFERENCES $TABLE_CATEGORIES($COL_CAT_ID) ON DELETE CASCADE
            );
        """.trimIndent()

        val createOrdersTable = """
            CREATE TABLE $TABLE_ORDERS (
                $COL_ORDER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_ORDER_DATE TEXT NOT NULL,
                $COL_ORDER_TYPE TEXT NOT NULL,
                $COL_ORDER_TABLE TEXT,
                $COL_ORDER_TOTAL REAL NOT NULL,
                $COL_ORDER_DISCOUNT REAL NOT NULL,
                $COL_ORDER_NET REAL NOT NULL,
                $COL_ORDER_PAYMENT_METHOD TEXT NOT NULL
            );
        """.trimIndent()

        val createOrderItemsTable = """
            CREATE TABLE $TABLE_ORDER_ITEMS (
                $COL_OI_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_OI_ORDER_ID INTEGER NOT NULL,
                $COL_OI_ITEM_NAME TEXT NOT NULL,
                $COL_OI_PRICE REAL NOT NULL,
                $COL_OI_QTY INTEGER NOT NULL,
                $COL_OI_TOTAL REAL NOT NULL,
                FOREIGN KEY ($COL_OI_ORDER_ID) REFERENCES $TABLE_ORDERS($COL_ORDER_ID) ON DELETE CASCADE
            );
        """.trimIndent()

        db.execSQL(createCategoriesTable)
        db.execSQL(createItemsTable)
        db.execSQL(createOrdersTable)
        db.execSQL(createOrderItemsTable)

        seedInitialData(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_ORDER_ITEMS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_ORDERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_ITEMS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_CATEGORIES")
        onCreate(db)
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    private fun seedInitialData(db: SQLiteDatabase) {
        val categories = listOf("Burgers", "Pizzas", "Mains", "Starters", "Beverages", "Desserts")
        val catIds = mutableMapOf<String, Long>()

        for (cat in categories) {
            val cv = ContentValues().apply { put(COL_CAT_NAME, cat) }
            val id = db.insert(TABLE_CATEGORIES, null, cv)
            catIds[cat] = id
        }

        val items = listOf(
            // Burgers
            Triple("Classic Cheeseburger", 8.99, catIds["Burgers"] ?: 1L),
            Triple("Smoky BBQ Bacon Burger", 11.49, catIds["Burgers"] ?: 1L),
            Triple("Crispy Chicken Sandwich", 9.99, catIds["Burgers"] ?: 1L),
            Triple("Double Truffle Smash Burger", 13.99, catIds["Burgers"] ?: 1L),
            // Pizzas
            Triple("Margherita Supreme Pizza", 12.50, catIds["Pizzas"] ?: 2L),
            Triple("Pepperoni Feast 12\"", 14.99, catIds["Pizzas"] ?: 2L),
            Triple("BBQ Chicken & Red Onion", 15.50, catIds["Pizzas"] ?: 2L),
            Triple("Four Cheese Delight", 13.99, catIds["Pizzas"] ?: 2L),
            // Mains
            Triple("Grilled Ribeye Steak 250g", 24.99, catIds["Mains"] ?: 3L),
            Triple("Creamy Garlic Prawn Pasta", 16.50, catIds["Mains"] ?: 3L),
            Triple("Herb Roasted Half Chicken", 15.99, catIds["Mains"] ?: 3L),
            Triple("Fish & Chips with Tartar", 13.99, catIds["Mains"] ?: 3L),
            // Starters
            Triple("Crispy Truffle Parmesan Fries", 5.99, catIds["Starters"] ?: 4L),
            Triple("Spicy Buffalo Chicken Wings", 8.50, catIds["Starters"] ?: 4L),
            Triple("Mozzarella Sticks & Marinara", 6.99, catIds["Starters"] ?: 4L),
            Triple("Loaded Cheesy Nachos", 7.99, catIds["Starters"] ?: 4L),
            // Beverages
            Triple("Signature Iced Latte", 4.50, catIds["Beverages"] ?: 5L),
            Triple("Fresh Mint Limeade", 3.99, catIds["Beverages"] ?: 5L),
            Triple("Craft Draft Soda", 2.99, catIds["Beverages"] ?: 5L),
            Triple("Peach Iced Tea", 3.75, catIds["Beverages"] ?: 5L),
            // Desserts
            Triple("Warm Molten Chocolate Cake", 6.50, catIds["Desserts"] ?: 6L),
            Triple("New York Cheesecake", 5.99, catIds["Desserts"] ?: 6L),
            Triple("Churros with Dulce de Leche", 5.50, catIds["Desserts"] ?: 6L)
        )

        for ((name, price, catId) in items) {
            val cv = ContentValues().apply {
                put(COL_ITEM_CAT_ID, catId)
                put(COL_ITEM_NAME, name)
                put(COL_ITEM_PRICE, price)
                put(COL_ITEM_IMAGE_PATH, "")
            }
            db.insert(TABLE_ITEMS, null, cv)
        }

        // Seed sample orders for daily sales demonstration
        val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        val cvOrder1 = ContentValues().apply {
            put(COL_ORDER_DATE, "$todayStr 10:15")
            put(COL_ORDER_TYPE, "Dine-In")
            put(COL_ORDER_TABLE, "Table 2")
            put(COL_ORDER_TOTAL, 13.49)
            put(COL_ORDER_DISCOUNT, 0.0)
            put(COL_ORDER_NET, 14.16)
            put(COL_ORDER_PAYMENT_METHOD, "Cash")
        }
        val orderId1 = db.insert(TABLE_ORDERS, null, cvOrder1)
        val cvItem1 = ContentValues().apply {
            put(COL_OI_ORDER_ID, orderId1)
            put(COL_OI_ITEM_NAME, "Classic Cheeseburger")
            put(COL_OI_PRICE, 8.99)
            put(COL_OI_QTY, 1)
            put(COL_OI_TOTAL, 8.99)
        }
        db.insert(TABLE_ORDER_ITEMS, null, cvItem1)

        val cvOrder2 = ContentValues().apply {
            put(COL_ORDER_DATE, "$todayStr 11:40")
            put(COL_ORDER_TYPE, "Dine-In")
            put(COL_ORDER_TABLE, "Table 4")
            put(COL_ORDER_TOTAL, 26.97)
            put(COL_ORDER_DISCOUNT, 2.0)
            put(COL_ORDER_NET, 26.22)
            put(COL_ORDER_PAYMENT_METHOD, "Card")
        }
        val orderId2 = db.insert(TABLE_ORDERS, null, cvOrder2)
        val cvItem2 = ContentValues().apply {
            put(COL_OI_ORDER_ID, orderId2)
            put(COL_OI_ITEM_NAME, "Pepperoni Feast 12\"")
            put(COL_OI_PRICE, 14.99)
            put(COL_OI_QTY, 1)
            put(COL_OI_TOTAL, 14.99)
        }
        db.insert(TABLE_ORDER_ITEMS, null, cvItem2)
    }

    // Category CRUD
    fun insertCategory(name: String): Long {
        val db = writableDatabase
        val cv = ContentValues().apply { put(COL_CAT_NAME, name) }
        return db.insert(TABLE_CATEGORIES, null, cv)
    }

    fun updateCategory(id: Long, name: String): Int {
        val db = writableDatabase
        val cv = ContentValues().apply { put(COL_CAT_NAME, name) }
        return db.update(TABLE_CATEGORIES, cv, "$COL_CAT_ID = ?", arrayOf(id.toString()))
    }

    fun deleteCategory(id: Long): Int {
        val db = writableDatabase
        return db.delete(TABLE_CATEGORIES, "$COL_CAT_ID = ?", arrayOf(id.toString()))
    }

    fun getAllCategories(): List<CategoryRecord> {
        val list = mutableListOf<CategoryRecord>()
        val db = readableDatabase
        val cursor: Cursor = db.query(TABLE_CATEGORIES, null, null, null, null, null, "$COL_CAT_ID ASC")
        cursor.use {
            val idIndex = it.getColumnIndexOrThrow(COL_CAT_ID)
            val nameIndex = it.getColumnIndexOrThrow(COL_CAT_NAME)
            while (it.moveToNext()) {
                list.add(CategoryRecord(it.getLong(idIndex), it.getString(nameIndex)))
            }
        }
        return list
    }

    // Item CRUD
    fun insertItem(categoryId: Long, name: String, price: Double, imagePath: String? = null, variants: String? = null): Long {
        val db = writableDatabase
        val cv = ContentValues().apply {
            put(COL_ITEM_CAT_ID, categoryId)
            put(COL_ITEM_NAME, name)
            put(COL_ITEM_PRICE, price)
            put(COL_ITEM_IMAGE_PATH, imagePath ?: "")
            put(COL_ITEM_VARIANTS, variants ?: "")
        }
        return db.insert(TABLE_ITEMS, null, cv)
    }

    fun updateItem(id: Long, categoryId: Long, name: String, price: Double, imagePath: String? = null, variants: String? = null): Int {
        val db = writableDatabase
        val cv = ContentValues().apply {
            put(COL_ITEM_CAT_ID, categoryId)
            put(COL_ITEM_NAME, name)
            put(COL_ITEM_PRICE, price)
            if (imagePath != null) put(COL_ITEM_IMAGE_PATH, imagePath)
            if (variants != null) put(COL_ITEM_VARIANTS, variants)
        }
        return db.update(TABLE_ITEMS, cv, "$COL_ITEM_ID = ?", arrayOf(id.toString()))
    }

    fun deleteItem(id: Long): Int {
        val db = writableDatabase
        return db.delete(TABLE_ITEMS, "$COL_ITEM_ID = ?", arrayOf(id.toString()))
    }

    fun getAllItems(): List<ItemRecord> {
        val list = mutableListOf<ItemRecord>()
        val db = readableDatabase
        val cursor: Cursor = db.query(TABLE_ITEMS, null, null, null, null, null, "$COL_ITEM_NAME ASC")
        cursor.use {
            val idIndex = it.getColumnIndexOrThrow(COL_ITEM_ID)
            val catIndex = it.getColumnIndexOrThrow(COL_ITEM_CAT_ID)
            val nameIndex = it.getColumnIndexOrThrow(COL_ITEM_NAME)
            val priceIndex = it.getColumnIndexOrThrow(COL_ITEM_PRICE)
            val imgIndex = it.getColumnIndexOrThrow(COL_ITEM_IMAGE_PATH)
            val varIndex = it.getColumnIndex(COL_ITEM_VARIANTS)
            while (it.moveToNext()) {
                val variantsStr = if (varIndex != -1) it.getString(varIndex) ?: "" else ""
                list.add(
                    ItemRecord(
                        id = it.getLong(idIndex),
                        categoryId = it.getLong(catIndex),
                        name = it.getString(nameIndex),
                        price = it.getDouble(priceIndex),
                        imagePath = it.getString(imgIndex) ?: "",
                        variants = variantsStr
                    )
                )
            }
        }
        return list
    }

    // Order insertion with transaction
    fun createOrder(
        orderDate: String,
        orderType: String,
        tableNumber: String,
        totalAmount: Double,
        discount: Double,
        netAmount: Double,
        paymentMethod: String,
        items: List<OrderItemRecord>
    ): Long {
        val db = writableDatabase
        db.beginTransaction()
        var orderId = -1L
        try {
            val cvOrder = ContentValues().apply {
                put(COL_ORDER_DATE, orderDate)
                put(COL_ORDER_TYPE, orderType)
                put(COL_ORDER_TABLE, tableNumber)
                put(COL_ORDER_TOTAL, totalAmount)
                put(COL_ORDER_DISCOUNT, discount)
                put(COL_ORDER_NET, netAmount)
                put(COL_ORDER_PAYMENT_METHOD, paymentMethod)
            }
            orderId = db.insert(TABLE_ORDERS, null, cvOrder)

            for (item in items) {
                val cvItem = ContentValues().apply {
                    put(COL_OI_ORDER_ID, orderId)
                    put(COL_OI_ITEM_NAME, item.itemName)
                    put(COL_OI_PRICE, item.price)
                    put(COL_OI_QTY, item.quantity)
                    put(COL_OI_TOTAL, item.total)
                }
                db.insert(TABLE_ORDER_ITEMS, null, cvItem)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return orderId
    }

    fun getAllOrders(): List<OrderRecord> {
        val list = mutableListOf<OrderRecord>()
        val db = readableDatabase
        val cursor = db.query(TABLE_ORDERS, null, null, null, null, null, "$COL_ORDER_ID DESC")
        cursor.use {
            val idIdx = it.getColumnIndexOrThrow(COL_ORDER_ID)
            val dateIdx = it.getColumnIndexOrThrow(COL_ORDER_DATE)
            val typeIdx = it.getColumnIndexOrThrow(COL_ORDER_TYPE)
            val tableIdx = it.getColumnIndexOrThrow(COL_ORDER_TABLE)
            val totalIdx = it.getColumnIndexOrThrow(COL_ORDER_TOTAL)
            val discIdx = it.getColumnIndexOrThrow(COL_ORDER_DISCOUNT)
            val netIdx = it.getColumnIndexOrThrow(COL_ORDER_NET)
            val payIdx = it.getColumnIndexOrThrow(COL_ORDER_PAYMENT_METHOD)

            while (it.moveToNext()) {
                list.add(
                    OrderRecord(
                        id = it.getLong(idIdx),
                        orderDate = it.getString(dateIdx),
                        orderType = it.getString(typeIdx),
                        tableNumber = it.getString(tableIdx) ?: "",
                        totalAmount = it.getDouble(totalIdx),
                        discount = it.getDouble(discIdx),
                        netAmount = it.getDouble(netIdx),
                        paymentMethod = it.getString(payIdx)
                    )
                )
            }
        }
        return list
    }

    fun getOrderItems(orderId: Long): List<OrderItemRecord> {
        val list = mutableListOf<OrderItemRecord>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_ORDER_ITEMS,
            null,
            "$COL_OI_ORDER_ID = ?",
            arrayOf(orderId.toString()),
            null,
            null,
            "$COL_OI_ID ASC"
        )
        cursor.use {
            val idIdx = it.getColumnIndexOrThrow(COL_OI_ID)
            val nameIdx = it.getColumnIndexOrThrow(COL_OI_ITEM_NAME)
            val priceIdx = it.getColumnIndexOrThrow(COL_OI_PRICE)
            val qtyIdx = it.getColumnIndexOrThrow(COL_OI_QTY)
            val totalIdx = it.getColumnIndexOrThrow(COL_OI_TOTAL)

            while (it.moveToNext()) {
                list.add(
                    OrderItemRecord(
                        id = it.getLong(idIdx),
                        orderId = orderId,
                        itemName = it.getString(nameIdx),
                        price = it.getDouble(priceIdx),
                        quantity = it.getInt(qtyIdx),
                        total = it.getDouble(totalIdx)
                    )
                )
            }
        }
        return list
    }
}

// Plain Kotlin data classes representing the SQLite tables
data class CategoryRecord(
    val id: Long = 0,
    val name: String
)

data class ItemRecord(
    val id: Long = 0,
    val categoryId: Long,
    val name: String,
    val price: Double,
    val imagePath: String = "",
    val variants: String = ""
)

data class OrderRecord(
    val id: Long = 0,
    val orderDate: String,
    val orderType: String,
    val tableNumber: String,
    val totalAmount: Double,
    val discount: Double,
    val netAmount: Double,
    val paymentMethod: String
)

data class OrderItemRecord(
    val id: Long = 0,
    val orderId: Long = 0,
    val itemName: String,
    val price: Double,
    val quantity: Int,
    val total: Double
)
