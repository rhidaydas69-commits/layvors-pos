package com.example.data.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String
)

data class ItemVariant(
    val name: String,
    val price: Double
)

fun List<ItemVariant>.toVariantsString(): String {
    return joinToString("|") { "${it.name.trim()}:${it.price}" }
}

@Entity(
    tableName = "items",
    foreignKeys = [
        ForeignKey(
            entity = Category::class,
            parentColumns = ["id"],
            childColumns = ["category_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["category_id"])]
)
data class Item(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "category_id")
    val categoryId: Long,
    val name: String,
    val price: Double,
    @ColumnInfo(name = "image_path")
    val imagePath: String = "",
    @ColumnInfo(name = "variants", defaultValue = "")
    val variants: String = ""
) {
    fun getVariantList(): List<ItemVariant> {
        if (variants.isBlank()) return emptyList()
        return variants.split("|").mapNotNull { entry ->
            val parts = entry.split(":")
            if (parts.size >= 2) {
                val vName = parts[0].trim()
                val vPrice = parts[1].trim().toDoubleOrNull() ?: 0.0
                if (vName.isNotBlank()) ItemVariant(vName, vPrice) else null
            } else null
        }
    }

    val hasVariants: Boolean get() = getVariantList().isNotEmpty()
}

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "order_date")
    val orderDate: String,
    @ColumnInfo(name = "order_type")
    val orderType: String, // "Dine-In", "Takeaway", "Delivery"
    @ColumnInfo(name = "table_number")
    val tableNumber: String,
    @ColumnInfo(name = "total_amount")
    val totalAmount: Double,
    val discount: Double,
    @ColumnInfo(name = "net_amount")
    val netAmount: Double,
    @ColumnInfo(name = "payment_method")
    val paymentMethod: String // "Cash", "Card", "UPI"
)

@Entity(
    tableName = "order_items",
    foreignKeys = [
        ForeignKey(
            entity = Order::class,
            parentColumns = ["id"],
            childColumns = ["order_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["order_id"])]
)
data class OrderItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "order_id")
    val orderId: Long,
    @ColumnInfo(name = "item_name")
    val itemName: String,
    val price: Double,
    val quantity: Int,
    val total: Double
)
