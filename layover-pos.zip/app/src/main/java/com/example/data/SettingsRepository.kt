package com.example.data

import android.content.Context
import android.content.SharedPreferences

data class PosSettings(
    val restaurantName: String = "Layover Cafe & Diner",
    val address: String = "742 Evergreen Terrace, Suite 100",
    val phone: String = "+1 (555) 019-2834",
    val taxRate: Double = 5.0, // 5%
    val currencySymbol: String = "$",
    val paperSize: PaperSize = PaperSize.MM_58,
    val footerMessage: String = "★ Thank You, Visit Again ★",
    val bluetoothDeviceAddress: String = ""
)

enum class PaperSize(val label: String, val charWidth: Int) {
    MM_58("58mm (32 chars)", 32),
    MM_80("80mm (48 chars)", 48)
}

class SettingsRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("pos_settings", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_REST_NAME = "rest_name"
        private const val KEY_ADDRESS = "address"
        private const val KEY_PHONE = "phone"
        private const val KEY_TAX_RATE = "tax_rate"
        private const val KEY_CURRENCY = "currency"
        private const val KEY_PAPER_SIZE = "paper_size"
        private const val KEY_FOOTER = "footer"
        private const val KEY_BT_DEVICE = "bt_device"
    }

    fun getSettings(): PosSettings {
        val paperStr = prefs.getString(KEY_PAPER_SIZE, PaperSize.MM_58.name) ?: PaperSize.MM_58.name
        val paperSize = try {
            PaperSize.valueOf(paperStr)
        } catch (_: Exception) {
            PaperSize.MM_58
        }

        return PosSettings(
            restaurantName = prefs.getString(KEY_REST_NAME, "Layover Cafe & Diner") ?: "Layover Cafe & Diner",
            address = prefs.getString(KEY_ADDRESS, "742 Evergreen Terrace, Suite 100") ?: "742 Evergreen Terrace, Suite 100",
            phone = prefs.getString(KEY_PHONE, "+1 (555) 019-2834") ?: "+1 (555) 019-2834",
            taxRate = prefs.getFloat(KEY_TAX_RATE, 5.0f).toDouble(),
            currencySymbol = prefs.getString(KEY_CURRENCY, "$") ?: "$",
            paperSize = paperSize,
            footerMessage = prefs.getString(KEY_FOOTER, "★ Thank You, Visit Again ★") ?: "★ Thank You, Visit Again ★",
            bluetoothDeviceAddress = prefs.getString(KEY_BT_DEVICE, "") ?: ""
        )
    }

    fun saveSettings(settings: PosSettings) {
        prefs.edit()
            .putString(KEY_REST_NAME, settings.restaurantName)
            .putString(KEY_ADDRESS, settings.address)
            .putString(KEY_PHONE, settings.phone)
            .putFloat(KEY_TAX_RATE, settings.taxRate.toFloat())
            .putString(KEY_CURRENCY, settings.currencySymbol)
            .putString(KEY_PAPER_SIZE, settings.paperSize.name)
            .putString(KEY_FOOTER, settings.footerMessage)
            .putString(KEY_BT_DEVICE, settings.bluetoothDeviceAddress)
            .apply()
    }
}
